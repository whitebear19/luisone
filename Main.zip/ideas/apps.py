from django.apps import AppConfig


class IdeasConfig(AppConfig):
    name = 'ideas'
