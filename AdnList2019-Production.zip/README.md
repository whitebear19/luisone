# AdnList2019-Test
Initial prototype of AdnList by Global State LLC
