<section id="listing_category" class="">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-left m-t-5">         
                <P class="category_detail"><a href="<?php echo e(url('/')); ?>" class="show_navigate_home"><span><i class="fa fa-home"></i></span></a><span class="show_navigate_status">User Dashboard</span></P>            
            </div>
        </div>
    </div>
</section><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/layouts/user_profile_header_normal.blade.php ENDPATH**/ ?>