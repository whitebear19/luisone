<?php $__env->startSection('title', __('Not Found')); ?>

<?php $__env->startSection('page_custom'); ?>
    <div>
        <h1 class="error_title">Oops, looks like the page is lost.</h1>
        <p class="error_content">This is not a fault, just an accident that was not intentional.</p>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\RMJ_working\workhistory\work\Ramana\www\AdnList2019\resources\views/errors/404.blade.php ENDPATH**/ ?>