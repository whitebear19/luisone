<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.user_profile_header_normal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="main" class="clearfix myads-page">
	<div class="container resp_padding_0">
		<?php echo $__env->make('layouts.user_profile_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="ads-info">
			<div class="row">
				<div class="col-sm-9">					
						<div class="">
							<ul class="p-l-0">
								<?php if(!empty($user_ads)): ?>
									<?php $__currentLoopData = $user_ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<?php
										$temp_time = strtotime($cur_date)-strtotime($item->created_at);
										$different_day  = floor($temp_time/(60*60*24));
										$different_hour = floor($temp_time/(60*60));
										$different_min  = ceil($temp_time/60);
										if($different_day>0)
										{
											$different_time = $different_day."days ago";
										}
										else
										{
											if($different_hour>0)
											{
												$different_time = $different_hour."hrs ago";
											}
											else
											{
												if($different_min<1)
												{
													$different_time = "1min ago";
												}
												else
												{
													$different_time = $different_min."min ago";
												}    
											}
										}                                                                                   
										$images = json_decode($item->post_image1);
									?>
										<li style="list-style-type:none;">
											<div class="user_ads_item">
												<div class="item-image">
													<a <?php if($item->user_confirm == "1"): ?> target="_blank" <?php endif; ?> href="<?php echo e(url('post_preview',$item->id)); ?>">
														<img src="<?php if(!empty($images) && file_exists('upload/img/poster/lg/'.$images['0'])): ?><?php echo e(asset('upload/img/poster/lg/'.$images['0'])); ?> <?php else: ?> <?php echo e(asset('assets/images/listing/no_image.jpg')); ?>  <?php endif; ?>"
															class="img-responsive">
													</a>                                                    
												</div> 
												<div class="" style="padding:10px;">
													<div class="ad-info">
														<?php if($item->status == 1): ?>
															<a target="_blank" href="<?php echo e(url('category_view/detail',[$item->id,'all'])); ?>"><h4 class="item-title"><?php echo e($item->title); ?></h4></a>
														<?php else: ?>
															<a <?php if($item->user_confirm == "1"): ?> target="_blank" <?php endif; ?> href="<?php echo e(url('post_preview',$item->id)); ?>"><h4 class="item-title"><?php echo e($item->title); ?></h4></a>
														<?php endif; ?>
																						
													</div>
													
													<div class="ad-meta">												
														<div class="date-country">
															<span class="m-r-20 fs-12"><a href="#"><i class="fa fa-dot-circle-o"></i> <?php echo e($different_time); ?></a></span> 
															<span class="fs-12"><a href="#"><i class="fa fa-map-marker"></i> <?php echo e($item->in_city); ?> <?php echo e($item->in_state); ?> <?php echo e($item->in_country); ?> </a></span>                                   
														</div>									
														
														<div class="user-option pull-right">
															<?php if($item->status == '0' || $item->status == '9'): ?>
																<?php if($item->user_confirm == '1'): ?>
																	<span data-toggle="tooltip" data-placement="top" title="Pending" class="text-color-purple fs-12"><b>Pending</b></span>
																<?php else: ?>
																	<span data-toggle="tooltip" data-placement="top" title="Draft" class="text-color-blue fs-12"><b>Draft</b></span>
																<?php endif; ?>
															<?php elseif($item->status == '1'): ?>
																<span data-toggle="tooltip" data-placement="top" title="Approved" class="text-color-green fs-12"><b>Approved</b></span>
															<?php elseif($item->status == '2'): ?>
																<span data-toggle="tooltip" data-placement="top" title="Inactive" class="text-color-green fs-12"><b>Inactive</b></span>
															<?php elseif($item->status == '3'): ?>
																<span data-toggle="tooltip" data-placement="top" title="Removed" class="text-color-red fs-12"><b>Removed</b></span>
															<?php endif; ?>
															<?php if($item->status < 3): ?>
																<a class="delete-item" href="<?php echo e(url('deleteads',$item->id)); ?>" data-toggle="tooltip" data-placement="top" title="Delete this ad"><i class="fa fa-times"></i></a>
															<?php endif; ?>
														</div>
													</div>    
												</div>																									
											</div>
										</li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								<?php endif; ?>
							</ul>                            
						</div>  
						<div class="text-center">							
							<?php echo e($user_ads->links()); ?>

						</div>
					
				</div>

				
				<div class="col-sm-3 text-center">
					
					<?php echo $__env->make('layouts.user_profile_recommended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
					
				</div>		
				
			</div>
		</div>
	</div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/user/user_advertisement.blade.php ENDPATH**/ ?>