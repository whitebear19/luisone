<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Adnlist</title>
</head>

<body style="background:#f1f1f1;padding-top:20px;padding-bottom:20px;">
    <center>
        <table class="" border="0" cellspacing="0" cellpadding="0" width="600"
            style="width:6.25in;background:#ffffff; border-collapse:collapse">
            <tbody>
                <tr>
                    <td height="10"></td>
                </tr>
                
                <tr>
                    <td style="padding-left:20px;" align="center">
                        <p style="font-weight:600;font-size:36px;"><span style="color:#004000;">Ad</span><span style="color:#99d9ea;">n</span><span style="color:#5fa659">List</span></p>
                    </td>
                </tr>
                <tr>
                    <td height="10"></td>
                </tr>
                <tr>
                    <td style="padding-left:20px;">
                        <?php if(!empty($data['status'])): ?>
                            <p style="margin:5px 0px 5px 0px;font-size:20px;color:#222;font-family: Montserrat;font-weight:500;">Dear <?php echo e($data['name']); ?>!</p>
                        <?php else: ?>
                            <p style="margin:5px 0px 5px 0px;font-size:20px;color:#222;font-family: Montserrat;font-weight:500;">Dear <?php echo e($data['fnameC']); ?>&nbsp;<?php echo e($data['lnameC']); ?>!</p>
                        <?php endif; ?>
                    </td>
                </tr>              
                <tr>
                    <td style="padding-left:50px;">
                        <table>
                            <tr>
                                <td style="padding-left: 20px;">
                                    <table>
                                        <tr>
                                            <td height="10"></td>
                                        </tr>
                                        <?php if(!empty($data['status'])): ?>
                                            <?php if($data['status'] == '2'): ?>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:18px;color:#222222;font-family: Montserrat;font-weight:600;">                                                                                
                                                            Your account on AdnList was <span style="color:#ff7a47;"><b>Deactivated!</b></span>.                                      
                                                        </p>                                   
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="10"></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">
                                                            For any further assistance contact our support team at <a href="mailto:" style="color:#0000ee;font-size:18px"><?php echo e($data["adminmail"]); ?></a> for any queries.
                                                        </p>
                                                    </td>
                                                </tr>
                                            <?php elseif($data['status'] == '1'): ?>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            Your account on AdnList was <span style="color:blue;"><b>re-activated successfully!</b></span>                                     
                                                        </p>                                   
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="10"></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">
                                                            For any further assistance cantact our support team at <a href="mailto:" style="color:#0000ee;font-size:18px"><?php echo e($data["adminmail"]); ?></a> for any queries.
                                                        </p>
                                                    </td>
                                                </tr>
                                            <?php elseif($data['status'] == 'del'): ?>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            Your post deleted successfully!                                     
                                                        </p>                                   
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="10"></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">
                                                            For any further assistance please contact support at <a href="mailto:" style="color:#0000ee;font-size:18px"><?php echo e($data["adminmail"]); ?></a>.
                                                        </p>
                                                    </td>
                                                </tr>
                                            <?php elseif($data['status'] == 'postup'): ?>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            Your pending approval post is updated successfully!                                  
                                                        </p>                                   
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="10"></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">
                                                            For any further assistance please contact support at &nbsp;<a href="mailto:" style="color:#0000ee;font-size:18px"><?php echo e($data["adminmail"]); ?></a>.
                                                        </p>
                                                    </td>
                                                </tr>  
                                            <?php elseif($data['status'] == 'verify'): ?>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:18px;color:#222222;font-family: Montserrat;font-weight:600;">                                                                                
                                                            Your email verified successfully! Thank you for joining AdnList.                                  
                                                        </p>                                   
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="10"></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">
                                                            For any further assistance please contact support at<a href="mailto:" style="color:#0000ee;font-size:18px"><?php echo e($data["adminmail"]); ?></a>.
                                                        </p>
                                                    </td>
                                                </tr>
                                            <?php elseif($data['status'] == 'sendlink'): ?>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:18px;color:#222222;font-family: Montserrat;font-weight:600;">                                                                                
                                                            Click link to verify your email:                              
                                                        </p>  
                                                        <a style="color:#222222;max-width:500px;overflow: hidden;box-sizing: border-box;overflow-wrap: break-word;display: block;font-size:14px;" href="<?php echo e(url('user_verify',$data['link'])); ?>"><?php echo e(url('user_verify',$data['link'])); ?></a>                                                          
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td height="10"></td>
                                                </tr>
                                                <tr>
                                                    <td>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">
                                                            For any further assistance please contact support at<a href="mailto:" style="color:#0000ee;font-size:18px"><?php echo e($data["adminmail"]); ?></a>.
                                                        </p>
                                                    </td>
                                                </tr>                           
                                            <?php endif; ?>
                                        <?php else: ?>  
                                            <tr>
                                                <td>
                                                    <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:600;">                                                                                
                                                        Your account following informations was updated on(<?php echo e(date('m/d/Y h:i:s a', time())); ?>)                                      
                                                    </p>                                   
                                                </td>
                                            </tr>
                                            <tr>
                                                <td height="10"></td>
                                            </tr>
                                            <tr>
                                                <td style="padding-left:30px;">
                                                    <?php if(!empty($data["p_image"])): ?>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            &ndash;&rsaquo;<?php echo e($data["p_image"]); ?>                                       
                                                        </p> 
                                                    <?php endif; ?>  
                                                    <?php if(!empty($data["fname"])): ?>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            &ndash;&rsaquo;<?php echo e($data["fname"]); ?>                                       
                                                        </p> 
                                                    <?php endif; ?>   
                                                    <?php if(!empty($data["lname"])): ?>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            &ndash;&rsaquo;<?php echo e($data["lname"]); ?>                                       
                                                        </p> 
                                                    <?php endif; ?>    
                                                    <?php if(!empty($data["p_phone"])): ?>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            &ndash;&rsaquo;<?php echo e($data["p_phone"]); ?>                                       
                                                        </p> 
                                                    <?php endif; ?>       
                                                    <?php if(!empty($data["p_location"])): ?>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            &ndash;&rsaquo;<?php echo e($data["p_location"]); ?>                                       
                                                        </p> 
                                                    <?php endif; ?>       
                                                    <?php if(!empty($data["p_zip"])): ?>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            &ndash;&rsaquo;<?php echo e($data["p_zip"]); ?>                                       
                                                        </p> 
                                                    <?php endif; ?>       
                                                    <?php if(!empty($data["p_type"])): ?>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            &ndash;&rsaquo;<?php echo e($data["p_type"]); ?>                                       
                                                        </p> 
                                                    <?php endif; ?>       
                                                    <?php if(!empty($data["p_phonecode"])): ?>
                                                        <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">                                                                                
                                                            &ndash;&rsaquo;<?php echo e($data["p_phonecode"]); ?>                                       
                                                        </p> 
                                                    <?php endif; ?>                    
                                                </td>
                                            </tr>
                                            <tr>
                                                <td height="10"></td>
                                            </tr>
                                            <tr>
                                                <td>
                                                    <p style="margin:5px 0px 5px 0px;font-size:16px;color:#222222;font-family: Montserrat;font-weight:500;">
                                                        For any further assistance please contact support at  <a href="mailto:" style="color:#0000ee;font-size:18px"><?php echo e($data["adminmail"]); ?></a>.
                                                    </p>
                                                </td>
                                            </tr>
                                        <?php endif; ?>
                                       
                                    </table>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                
                <tr>
                    <td height="10"></td>
                </tr>
                

                <tr>
                    <td height="10"></td>
                </tr>
                <tr>
                    <td style="padding-left:20px;">
                        <p style="margin:5px 0px 5px 0px;font-size:18px;color:#222;font-family: initial;font-weight:600;">
                            Adnlist team
                        </p>
                        <p style="margin:5px 0px 5px 0px;font-size:18px;color: #222;font-family: initial;font-weight:500;">
                            Maricopa,AZ,USA
                        </p>
                    </td>
                </tr>
                <tr>
                    <td height="30"></td>
                </tr>
            </tbody>
        </table>


    </center>
</body>

</html>
<?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/email/updateprofile.blade.php ENDPATH**/ ?>