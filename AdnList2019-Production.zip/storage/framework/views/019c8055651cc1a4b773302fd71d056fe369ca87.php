<?php $__env->startSection('title', __('Page Expired')); ?>


<?php $__env->startSection('page_custom'); ?>
    <div>
        <h1 class="error_title">Page Expired!</h1>        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/errors/419.blade.php ENDPATH**/ ?>