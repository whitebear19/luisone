<div class="section quick-rules">
    <h4><?php echo e(trans('message.cp_quick_tips')); ?></h4>
    <p class="lead"><?php echo e(trans('message.cp_quick_tips_text')); ?></p>

    <ul>
        <li><?php echo e(trans('message.cp_quick_tips_text1')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text2')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text3')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text4')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text5')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text6')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text7')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text8')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text91')); ?> <a href="<?php echo e(route('posting_tips')); ?>" target="_blank" class="text-color-blue">“<?php echo e(trans('message.cp_quick_tips_text92')); ?>”</a> <?php echo e(trans('message.cp_quick_tips_text93')); ?></li>
        <li><?php echo e(trans('message.cp_quick_tips_text10')); ?></li>
    </ul>
</div><?php /**PATH E:\RMJ_working\workhistory\work\Ramana\www\AdnList2019\resources\views/layouts/posting_tips.blade.php ENDPATH**/ ?>