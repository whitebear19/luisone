<?php $__env->startSection('content'); ?>
<style>
    .error_text{padding: 200px;}
    .error_text h3{color:#0000ee;}
    @media(max-width:700px)
    {
        .error_text{
        text-align: center;
        padding: 200px 20px;        
    }
    }
</style>

<section id="error_page_banner" style="height:70vh;background-size:contain;">
    <div class="error_text">          
        <h3>Oops, post not found!</h3>        
    </div>
</section>   

<?php $__env->stopSection(); ?>
	

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/nopost.blade.php ENDPATH**/ ?>