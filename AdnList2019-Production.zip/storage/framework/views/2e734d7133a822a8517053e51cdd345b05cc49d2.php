

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<div class="ad-profile section">	
    <div class="user-profile">
       
        <div class="user">
            <h2 class="m-t-10"><span class="fs-18"><?php echo e(trans('message.userprofile_welcome')); ?></span> <span class="text-color-blue fs-20"> <?php if(!empty(Auth::user()->name)): ?><?php echo e(Auth::user()->name); ?> <?php else: ?> <?php if(!empty(Auth::user()->fname)): ?><?php echo e(Auth::user()->fname); ?> <?php endif; ?> <?php if(!empty(Auth::user()->lname)): ?><?php echo e(Auth::user()->lname); ?> <?php endif; ?>  <?php endif; ?></span></h2>            
        </div>
        <div style="float:right;" class="m-t-5">
            <form action="<?php echo e(route('update_user_status')); ?>" id="deactivate_form" class="update_user_status_form">
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                <input type="hidden" name="user_status" value="2">
                <input type="hidden" name="user_side" value="true">
                <button type="button" class="btn btn-cancel delete_button_user"><?php echo e(trans('message.userprofile_deactivate')); ?></button>                        
            </form>     
        </div>
    </div>
            
    <ul class="user-menu">
        <li class="<?php if($page_name == 'profile'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_profile')); ?>"><?php echo e(trans('message.userprofile_profile')); ?></a></li>
        <li class="<?php if($page_name == 'pwd'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_change_password')); ?>"><?php echo e(trans('message.userprofile_changepwd')); ?></a></li>
        <?php if(Auth::user()->role == "0"): ?>
            <li class="<?php if($page_name == 'notification'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_messages','read')); ?>"><?php echo e(trans('message.userprofile_notification')); ?><span>(<?php if(!empty($userDetail['user_num_unread'])): ?><?php echo e($userDetail['user_num_unread']); ?><?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <li class="<?php if($page_name == 'ads'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_advertisement')); ?>"><?php echo e(trans('message.userprofile_activeposts')); ?><span>(<?php if(!empty($userDetail['user_ads_num'])): ?><?php echo e($userDetail['user_ads_num']); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <li class="<?php if($page_name == 'pen'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_pending_approval_ads')); ?>"><?php echo e(trans('message.userprofile_pending')); ?><span>(<?php if(!empty($userDetail['user_pending_num'])): ?><?php echo e($userDetail['user_pending_num']); ?><?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <li class="<?php if($page_name == 'draft'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_draft_ads')); ?>"><?php echo e(trans('message.userprofile_draft')); ?><span>(<?php if(!empty($userDetail['user_draft_num'])): ?><?php echo e($userDetail['user_draft_num']); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <li class="<?php if($page_name == 'expired'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_expired_ads')); ?>"><?php echo e(trans('message.userprofile_expired')); ?><span>(<?php if(!empty($userDetail['user_expired_num'])): ?><?php echo e($userDetail['user_expired_num']); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
        <?php elseif(Auth::user()->role == "1"): ?>
            <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_messages','read')); ?>"><?php echo e(trans('message.userprofile_messages')); ?></a></li>
            <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_advertisement')); ?>"><?php echo e(trans('message.userprofile_mylisting')); ?><span>(<?php if(!empty($user_ads_num)): ?><?php echo e($user_ads_num); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_pending_approval_ads')); ?>"><?php echo e(trans('message.userprofile_sold')); ?><span>(<?php if(!empty($user_pendding_num)): ?><?php echo e($user_pendding_num); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_draft_ads')); ?>"><?php echo e(trans('message.userprofile_selling')); ?><span>(<?php if(!empty($user_draft_num)): ?><?php echo e($user_draft_num); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_draft_ads')); ?>"><?php echo e(trans('message.userprofile_waiting')); ?><span>(<?php if(!empty($user_draft_num)): ?><?php echo e($user_draft_num); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
        <?php endif; ?>
    </ul>
</div>
<script>
    $(function() {
        $(".delete_button_user").click(function(){
            if (confirm("Conformation! Do you really want to deactivate this account?"))
            {
                $('form#deactivate_form').submit();
            }
        });
    });
</script><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/layouts/user_profile_header.blade.php ENDPATH**/ ?>