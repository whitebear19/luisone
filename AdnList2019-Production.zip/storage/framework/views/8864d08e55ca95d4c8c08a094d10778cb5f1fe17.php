<?php $__env->startSection('content'); ?>

 
 <div class="content-wrapper">
     
      <section class="content-header">
        <h3>Manage price plan</h3>        
      </section>      
      <section class="content">        
        <div class="row">          
            <div class="col-xs-12">
                <div class="normal_border">
                    <form action="<?php echo e(route('admin_price')); ?>" class="plan_update_form" method="POST">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-xs-2">
                                <label for="">Category</label>
                            </div>
                            <div class="col-xs-10">
                                <select type="text" name="selected_category_slug" class="form-control selected_category" required>
                                    <option value=""></option>
                                    <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(($cur_category !="") && ($item->slug == $cur_category->slug)): ?> selected <?php endif; ?> value="<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                </select>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-xs-2">                            
                            </div>
                            <div class="col-xs-10">
                                <div class="price_plan_part">
                                    <ul class="price_plan_ul">
                                        <li>
                                            <div class="price_plan_item">
                                                <div class="align-center">
                                                    <label for="" class="price_plan_item_title">Basic</label>
                                                </div>
                                                <div class="price_plan_item_body">
                                                    <label for="" class="price_plan_item_title">7Days</label>
                                                    <img class="price_plan_calander_img" src="<?php echo e(asset('assets/images/calander.png')); ?>" alt="" srcset="">
                                                    <label for="" class="price_plan_item_price">Free</label>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="price_plan_item">
                                                <div class="align-center">
                                                    <label for="" class="price_plan_item_title">Premium</label>
                                                </div>
                                                <div class="price_plan_item_body">
                                                    <label for="" class="price_plan_item_title">15Days</label>
                                                    <img class="price_plan_calander_img" src="<?php echo e(asset('assets/images/calander.png')); ?>" alt="" srcset="">
                                                    <?php if($cur_category != ""): ?>
                                                        <label for="" class="price_plan_item_price">Price:<?php echo e($cur_category->premium); ?>$</label>
                                                    <?php else: ?>
                                                        <label for="" class="price_plan_item_price">No select</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="price_plan_item">
                                                <div class="align-center">
                                                    <label for="" class="price_plan_item_title">Platinum</label>
                                                </div>
                                                <div class="price_plan_item_body">
                                                    <label for="" class="price_plan_item_title">30Days</label>
                                                    <img class="price_plan_calander_img" src="<?php echo e(asset('assets/images/calander.png')); ?>" alt="" srcset="">
                                                    <?php if($cur_category != ""): ?>
                                                        <label for="" class="price_plan_item_price">Price:<?php echo e($cur_category->platinum); ?>$</label>
                                                    <?php else: ?>
                                                        <label for="" class="price_plan_item_price">No select</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="price_plan_item">
                                                <div class="align-center">
                                                    <label for="" class="price_plan_item_title">Dimond</label>
                                                </div>
                                                <div class="price_plan_item_body">
                                                    <label for="" class="price_plan_item_title">45Days</label>
                                                    <img class="price_plan_calander_img" src="<?php echo e(asset('assets/images/calander.png')); ?>" alt="" srcset="">
                                                    <?php if($cur_category != ""): ?>
                                                        <label for="" class="price_plan_item_price">Price:<?php echo e($cur_category->dimond); ?>$</label>
                                                    <?php else: ?>
                                                        <label for="" class="price_plan_item_price">No select</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>                            
                            </div>
                        </div>
                    
                        <div class="row">
                            <div class="col-xs-2">
                                <label for="">Change</label>
                            </div>
                            <div class="col-xs-10">
                                <div style="border:1px solid #616161;">
                                    <ul class="price_plan_ul">
                                        <li>
                                            <input type="text" name="price_basic" placeholder="Free" disabled class="form-control">
                                        </li>
                                        <li>
                                            <input type="text" name="price_premium" placeholder="New price" class="form-control">
                                        </li>
                                        <li>
                                            <input type="text" name="price_platinum" placeholder="New price" class="form-control">
                                        </li>
                                        <li>
                                            <input type="text" name="price_dimond" placeholder="New price" class="form-control">
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-xs-10 text-center">
                                <button class="add_newaccount_btn btn_search m-t-10">Update</button>
                            </div>
                        </div>
                    </form>                        
                </div>
            </div> 
        </div>
      </section>

      <section class="content-header">
        <h3>Manage price plan for third party advertisements</h3>        
      </section>      
      <section class="content">        
        <div class="row">          
            <div class="col-xs-12">
                <div class="normal_border">
                    <form action="<?php echo e(route('admin_price')); ?>" class="" method="POST">
                    <?php echo csrf_field(); ?>
                        <input type="hidden" name="which" value="adv">
                        <div class="row">
                            <div class="col-xs-2">                            
                            </div>
                            <div class="col-xs-10">
                                <div class="price_plan_part">
                                    <ul class="price_plan_ul">                                        
                                        <li>
                                            <div class="price_plan_item">
                                                <div class="align-center">
                                                    <label for="" class="price_plan_item_title">Premium</label>
                                                </div>
                                                <div class="price_plan_item_body">
                                                    <label for="" class="price_plan_item_title">15Days</label>
                                                    <img class="price_plan_calander_img" src="<?php echo e(asset('assets/images/calander.png')); ?>" alt="" srcset="">
                                                    <?php if($site_record != ""): ?>
                                                        <label for="" class="price_plan_item_price">Price:<?php echo e($site_record->price_premium); ?>$</label>
                                                    <?php else: ?>
                                                        <label for="" class="price_plan_item_price">No price</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="price_plan_item">
                                                <div class="align-center">
                                                    <label for="" class="price_plan_item_title">Platinum</label>
                                                </div>
                                                <div class="price_plan_item_body">
                                                    <label for="" class="price_plan_item_title">30Days</label>
                                                    <img class="price_plan_calander_img" src="<?php echo e(asset('assets/images/calander.png')); ?>" alt="" srcset="">
                                                    <?php if($site_record != ""): ?>
                                                        <label for="" class="price_plan_item_price">Price:<?php echo e($site_record->price_platinum); ?>$</label>
                                                    <?php else: ?>
                                                        <label for="" class="price_plan_item_price">No price</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </li>
                                        <li>
                                            <div class="price_plan_item">
                                                <div class="align-center">
                                                    <label for="" class="price_plan_item_title">Dimond</label>
                                                </div>
                                                <div class="price_plan_item_body">
                                                    <label for="" class="price_plan_item_title">45Days</label>
                                                    <img class="price_plan_calander_img" src="<?php echo e(asset('assets/images/calander.png')); ?>" alt="" srcset="">
                                                    <?php if($site_record != ""): ?>
                                                        <label for="" class="price_plan_item_price">Price:<?php echo e($site_record->price_dimond); ?>$</label>
                                                    <?php else: ?>
                                                        <label for="" class="price_plan_item_price">No price</label>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </li>
                                    </ul>
                                </div>                            
                            </div>
                        </div>
                    
                        <div class="row">
                            <div class="col-xs-2">
                                <label for="">Change</label>
                            </div>
                            <div class="col-xs-10">
                                <div style="border:1px solid #616161;">
                                    <ul class="price_plan_ul">                                       
                                        <li>
                                            <input type="text" name="price_premium" placeholder="New price" class="form-control">
                                        </li>
                                        <li>
                                            <input type="text" name="price_platinum" placeholder="New price" class="form-control">
                                        </li>
                                        <li>
                                            <input type="text" name="price_dimond" placeholder="New price" class="form-control">
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="col-xs-10 text-center">
                                <button class="add_newaccount_btn btn_search m-t-10">Update</button>
                            </div>
                        </div>
                    </form>                        
                </div>
            </div> 
        </div>
      </section>
    </div>    
    <script>    
        $(document).ready(function(){
            $(".selected_category").change(function(){
                $(".plan_update_form").submit();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/admin/price.blade.php ENDPATH**/ ?>