

<?php $__env->startSection('style'); ?>
<link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
    
<?php $__env->stopSection(); ?>
<div class="ad-profile section">	
    <div class="user-profile">
       
        <div class="user">
            <h2 class="m-t-10"><span class="fs-18"><?php echo e(trans('message.userprofile_welcome')); ?></span> <span class="text-color-blue fs-20"> <?php if(!empty(Auth::user()->name)): ?><?php echo e(Auth::user()->name); ?> <?php else: ?> <?php if(!empty(Auth::user()->fname)): ?><?php echo e(Auth::user()->fname); ?> <?php endif; ?> <?php if(!empty(Auth::user()->lname)): ?><?php echo e(Auth::user()->lname); ?> <?php endif; ?>  <?php endif; ?></span></h2>            
        </div>
        <div style="float:right;" class="m-t-5">
            <form action="<?php echo e(route('update_user_status')); ?>" id="deactivate_form" class="update_user_status_form">
                <input type="hidden" name="user_id" value="<?php echo e(Auth::user()->id); ?>">
                <input type="hidden" name="user_status" value="2">
                <input type="hidden" name="user_side" value="true">
                <button type="button" class="btn btn-cancel delete_button_user">Deactivate account</button>                        
            </form>     
        </div>
    </div>
            
    <div class="user_account_nav_wrap">
        <ul class="user-menu">
            <li class="<?php if($page_name == 'profile'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_profile')); ?>"><?php echo e(trans('message.userprofile_profile')); ?></a></li>
            <li class="<?php if($page_name == 'pwd'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_change_password')); ?>"><?php echo e(trans('message.userprofile_changepwd')); ?></a></li>
            <?php if(Auth::user()->role == "0"): ?>
                <li class="<?php if($page_name == 'notification'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_messages','read')); ?>">Messages<span>(<?php if(!empty($userDetail['user_num_unread'])): ?><?php echo e($userDetail['user_num_unread']); ?><?php else: ?> 0 <?php endif; ?>)</span></a></li>
                <li class="<?php if($page_name == 'ads'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_advertisement')); ?>"><?php echo e(trans('message.userprofile_activeposts')); ?><span>(<?php if(!empty($userDetail['user_ads_num'])): ?><?php echo e($userDetail['user_ads_num']); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
                <li class="<?php if($page_name == 'pen'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_pending_approval_ads')); ?>"><?php echo e(trans('message.userprofile_pending')); ?><span>(<?php if(!empty($userDetail['user_pending_num'])): ?><?php echo e($userDetail['user_pending_num']); ?><?php else: ?> 0 <?php endif; ?>)</span></a></li>
                <li class="<?php if($page_name == 'draft'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_draft_ads')); ?>"><?php echo e(trans('message.userprofile_draft')); ?><span>(<?php if(!empty($userDetail['user_draft_num'])): ?><?php echo e($userDetail['user_draft_num']); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
                <li class="<?php if($page_name == 'expired'): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_expired_ads')); ?>"><?php echo e(trans('message.userprofile_expired')); ?><span>(<?php if(!empty($userDetail['user_expired_num'])): ?><?php echo e($userDetail['user_expired_num']); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <?php elseif(Auth::user()->role == "1"): ?>
                <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_messages','read')); ?>"><?php echo e(trans('message.userprofile_messages')); ?></a></li>
                <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_advertisement')); ?>"><?php echo e(trans('message.userprofile_mylisting')); ?><span>(<?php if(!empty($user_ads_num)): ?><?php echo e($user_ads_num); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
                <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_pending_approval_ads')); ?>"><?php echo e(trans('message.userprofile_sold')); ?><span>(<?php if(!empty($user_pendding_num)): ?><?php echo e($user_pendding_num); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
                <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_draft_ads')); ?>"><?php echo e(trans('message.userprofile_selling')); ?><span>(<?php if(!empty($user_draft_num)): ?><?php echo e($user_draft_num); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
                <li class="<?php if($page_name == ''): ?> active <?php endif; ?>"><a href="<?php echo e(route('user_draft_ads')); ?>"><?php echo e(trans('message.userprofile_waiting')); ?><span>(<?php if(!empty($user_draft_num)): ?><?php echo e($user_draft_num); ?> <?php else: ?> 0 <?php endif; ?>)</span></a></li>
            <?php endif; ?>
        </ul>
    </div>
    
</div>
<script>
    $(function() {
        $(".delete_button_user").click(function(){
            if (confirm("Confirmation! Do you really want to deactivate this account?"))
            {
                $('form#deactivate_form').submit();
            }
        });        
    });
    function setSlick()
    {
        $(".user-menu").slick({
			dots: false,
			infinite: true,
			speed: 500,
			slidesToShow: 1,
			centerMode: false,
			variableWidth: true
		});
		var right_arrow = `
			<svg class="size-20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-circle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-chevron-circle-right fa-w-16 fa-3x"><path fill="currentColor" d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm113.9 231L234.4 103.5c-9.4-9.4-24.6-9.4-33.9 0l-17 17c-9.4 9.4-9.4 24.6 0 33.9L285.1 256 183.5 357.6c-9.4 9.4-9.4 24.6 0 33.9l17 17c9.4 9.4 24.6 9.4 33.9 0L369.9 273c9.4-9.4 9.4-24.6 0-34z" class=""></path></svg>
		`;
		$(".slick-next").html(right_arrow);
		var left_arrow = `
			<svg class="size-20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-circle-left" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-chevron-circle-left fa-w-16 fa-2x"><path fill="currentColor" d="M256 504C119 504 8 393 8 256S119 8 256 8s248 111 248 248-111 248-248 248zM142.1 273l135.5 135.5c9.4 9.4 24.6 9.4 33.9 0l17-17c9.4-9.4 9.4-24.6 0-33.9L226.9 256l101.6-101.6c9.4-9.4 9.4-24.6 0-33.9l-17-17c-9.4-9.4-24.6-9.4-33.9 0L142.1 239c-9.4 9.4-9.4 24.6 0 34z" class=""></path></svg>
		`;
		$(".slick-prev").html(left_arrow);
    }
    $(document).ready(function(){
        if ($(window).width() < 960) {
            setSlick()
        }        
    });
</script><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/layouts/user_profile_header.blade.php ENDPATH**/ ?>