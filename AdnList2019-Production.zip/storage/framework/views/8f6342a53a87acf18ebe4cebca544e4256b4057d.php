<?php $__env->startSection('content'); ?>

<section id="main" class="clearfix contact-us">
    <div class="container">
        <div class="row">
            <div class="col-md-12 m-t-60">
                <h2 class="home_title text-center">Verify Email</h2>               
            </div>
            <div class="col-md-2"></div>
            <div class="col-md-8">
                <div class="contactus m-t-10" style="min-height:500px;">
                    <h4 class="title text-center">Welcome to our <b>adnlist.com</b></h4>
                                
                    <div class="p-t-50">
                        <div class="container-register">
                            <div class="wrap-register">
                                
                                <div class="card">
                                    <div class="card-header">
                                        <form action="<?php echo e(route('emailtextverify')); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                            <div class="row">
                                                <div class="col-12 col-md-6 align-center">
                                                    <b class="fs-20"><?php echo e(__('Verify Your Email Address')); ?></b>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <input type="email" class="form-control fs-20" name="user_verify_email" value="<?php echo e(Auth::user()->email); ?>" disabled>
                                                </div>
                                            </div>
                                            <div class="row m-t-30">
                                                <div class="col-12 col-md-6 align-center">
                                                    <b class="fs-20"><?php echo e(__('Enter Verification code sent to mail')); ?></b>
                                                </div>
                                                <div class="col-12 col-md-6">
                                                    <input type="text" class="form-control" name="user_verify_text" value="" autocomplete="off" required>
                                                </div>
                                                <div class="col-md-12 align-center m-t-60 m-b-20 text-center">
                                                    <button class="btn btn-green" style="padding:8px 40px; font-size:20px;">Verify</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>

                                    <div class="card-body">
                                        <?php if(session('error')): ?>
                                            <div class="alert alert-warning alert-dismissible show align-center">
                                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                                                <span class="text-color-red fs-16"><?php echo e(session('error')); ?></span>
                                            </div>
                                        <?php endif; ?>
                                        
                                        <?php if(session('success')): ?>
                                            <div class="alert alert-success alert-dismissible" role="alert">
                                                <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                                <strong>Success!</strong> <span><?php echo e(session('success')); ?></span>
                                            </div>
                                        <?php endif; ?>

                                        <p><?php echo e(__('Before proceeding, please check your email for a verification text.')); ?>

                                        <?php echo e(__('If you did not receive the email')); ?>, <a href="<?php echo e(route('requestanother')); ?>" style="color:#28a745;"><?php echo e(__('click here to request another')); ?></a>.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                </div>
            </div>
            <div class="col-md-2"></div>
        </div>
            
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/emailverify.blade.php ENDPATH**/ ?>