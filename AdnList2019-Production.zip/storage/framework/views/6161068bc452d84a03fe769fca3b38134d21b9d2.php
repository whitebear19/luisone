<?php $__env->startSection('content'); ?>

 
 <div class="content-wrapper">
     
      <section class="content-header">
        <h3>Phone Numbers</h3>        
      </section>      
      <section class="content">        
        <div class="row">          
          <div class="col-xs-12">
            <?php if($phones): ?>
                <div class="box-body table-responsive m-t-30">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Phone Number</th>
                                <th>Date</th>                           
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $phones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><span><?php echo e($item->phone_number); ?></span></td>
                                    <td><span><?php echo e($item->created_at); ?></span></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                        </tbody>
                    </table>
                    <div style="text-align:center;">
                        <?php echo e($phones->links()); ?>                
                    </div>
                </div>  
               
            <?php endif; ?>
                          
              
            </div>
          </div> 
        </div>     

      </section>
    </div>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/admin/phone.blade.php ENDPATH**/ ?>