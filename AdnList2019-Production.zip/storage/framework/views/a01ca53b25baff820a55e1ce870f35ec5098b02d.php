<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta content="" name="description" />
    <meta content="webthemez" name="author" />
    <title>AdnList</title>
    <link rel="shortcut icon" href="<?php echo e(asset('assets/images/favicon-icon/favicon.png')); ?>">
    <link href="<?php echo e(asset('adnlist_admin/css/bootstrap.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('adnlist_admin/css/font-awesome.css')); ?>" rel="stylesheet" />
    
    <link href="<?php echo e(asset('adnlist_admin/css/admin-styles.css')); ?>" rel="stylesheet" />
    <link href="<?php echo e(asset('adnlist_admin/css/util.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('adnlist_admin/js/Lightweight-Chart/cssCharts.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/accordion.css')); ?>">
    <link href="<?php echo e(asset('assets/css/summernote-bs4.css')); ?>" rel="stylesheet">
    
    <?php echo $__env->yieldContent('style'); ?>
    <script src="<?php echo e(asset('adnlist_admin/js/jquery-1.10.2.js')); ?>"></script>
    <script src="<?php echo e(asset('adnlist_admin/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('adnlist_admin/js/jquery.metisMenu.js')); ?>"></script>
    <script src="<?php echo e(asset('adnlist_admin/js/morris/raphael-2.1.0.min.js')); ?>"></script>
   
    <script src="<?php echo e(asset('adnlist_admin/js/easypiechart.js')); ?>"></script>
    <script src="<?php echo e(asset('adnlist_admin/js/easypiechart-data.js')); ?>"></script>
    <script src="<?php echo e(asset('adnlist_admin/js/Lightweight-Chart/jquery.chart.js')); ?>"></script>
    <script src="<?php echo e(asset('adnlist_admin/js/custom-scripts.js')); ?>"></script>   
    <script type="text/javascript" src="<?php echo e(asset('adnlist_admin/js/chart.min.js')); ?>"></script>   
    <script src="<?php echo e(asset('assets/js/accordion.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/summernote-bs4.min.js')); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</head>

<body>
    <div id="wrapper">
        <nav class="navbar navbar-default top-navbar" role="navigation">
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                    <span class="sr-only"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <div id="sideNav" href="">
                    <i class="fa fa-chevron-left icon" style="font-size:25px;line-height:50px;"></i>
                </div>
                <a class="navbar-brand text-center m-l-20" href="<?php echo e(url('/admin/dashboard')); ?>"><img style="width:160px;" src="<?php echo e(asset('adnlist_admin/images/logo.png')); ?>" alt=""></a>
                
            </div>

            <ul class="nav navbar-top-links navbar-right mobile_hidden">
                <li class="dropdown" style="line-height:40px;">
                    <a class="dropdown-toggle nav_user_info" data-toggle="dropdown" href="#" aria-expanded="false">                       
                        <span class="admin_info"><?php echo e(Auth::user()->fname); ?> <?php echo e(Auth::user()->lname); ?></span> 
                    </a>                    

                </li>

            </ul>
        </nav>

        <nav class="navbar-default navbar-side" role="navigation">
            <div class="sidebar-collapse">
                <ul class="nav" id="main-menu">

                    <li>
                        <a class="<?php if($admin_page == 'dashboard'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_dashboard')); ?>"><i class="fa fa-dashboard"></i> Dashboard</a>
                    </li>
                   
                    <li>
                        <a class="<?php if($admin_page == 'accounts'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_accounts')); ?>"><i class="fa fa-qrcode"></i>Accounts</a>
                    </li>

                    <li>
                        <a class="<?php if($admin_page == 'price'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_price')); ?>"><i class="fa fa-qrcode"></i>Manage price plan</a>
                    </li>

                    <li>
                        <a class="<?php if($admin_page == 'additional'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_addtional')); ?>"><i class="fa fa-qrcode"></i>Manage additional text</a>
                    </li>

                    <li>
                        <a class="<?php if($admin_page == 'accounts_pro'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_accounts_pro')); ?>"><i class="fa fa-qrcode"></i>Professional Accounts</a>
                    </li>

                    <li>
                        <a class="<?php if($admin_page == 'tasks'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_tasks','all')); ?>"><i class="fa fa-table"></i> All Tasks</a>
                    </li>

                    <li>
                        <a class="<?php if($admin_page == 'ads'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_ads')); ?>"><i class="fa fa-table"></i> Third Party Advertisements</a>
                    </li>
                    <?php if(Auth::user()->role > '2'): ?>
                    <li>
                        <a class="<?php if($admin_page == 'subadmin'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_subadmin')); ?>"><i class="fa fa-user"></i>Sub Admin</a>
                    </li>
                    <li>
                        <a class="<?php if($admin_page == 'category'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_category')); ?>"><i class="fa fa-edit"></i>Categories</a>
                    </li>
                    <li>
                        <a class="<?php if($admin_page == 'profile'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_profile')); ?>"><i class="fa fa-user"></i>Profile Categories</a>
                    </li>
                    <li>
                        <a class="<?php if($admin_page == 'country'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_country')); ?>"><i class="fa fa-globe"></i>Country</a>                        
                    </li>  
                    <?php endif; ?>   

                    <li>
                        <a class="<?php if($admin_page == 'info'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_info')); ?>"><i class="fa fa-desktop"></i>Admin Info</a>
                    </li>  
                    <li>
                        <a class="<?php if($admin_page == 'cinfo'): ?> active-menu  <?php endif; ?>" href="<?php echo e(route('admin_company_info')); ?>"><i class="fa fa-building-o"></i>Company Info</a>
                    </li>    
                    <li>
                        <a class="<?php if($admin_page == 'footer_edit'): ?> active-menu  <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"privacy")); ?>"><i class="fa fa-edit"></i>Footer Edit</a>
                    </li>                                  
                    <li>                        
                        <a class="dropdown-item logout" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();document.getElementById('logout-form').submit();"><i class="fa fa-sign-out"></i><label for="" class="btn-logout">Logout</label></a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>

                </ul>

            </div>

        </nav>


        <div id="adnlist-page-wrapper">

            <div id="adnlist-page-inner">                
                <?php echo $__env->yieldContent('content'); ?>
            </div>
            <footer>
                <p>All right reserved. Designed by: <a href="">AdnList.com</a></p>
            </footer>
        </div>
    </div>
    
</body>
    <script src="https://maps.googleapis.com/maps/api/js?key=<?php echo e(env('MAP_API_KEY')); ?>&libraries=places&callback=initMap" async defer></script>
</html><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/layouts/admin.blade.php ENDPATH**/ ?>