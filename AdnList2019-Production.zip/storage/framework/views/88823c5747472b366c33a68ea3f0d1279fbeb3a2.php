<?php $__env->startSection('content'); ?>

 
 <div class="content-wrapper">
     
      <section class="content-header">
        <h3>Manage price plan</h3>        
      </section>      
      <section class="content">      
        <div class="normal_border">  
            <div class="row">  
                <div class="col-md-6">
                    <label for="">Category</label>
                    <select name="" class="form-control category_list">
                        <option value="">-- Select --</option>
                        <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($item->price); ?>" data-id="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="">Price($)</label>
                    <input type="number" class="form-control input_price" value="">
                </div>
                
                <div class="col-md-12 m-t-20 text-center">
                    <button class="btn_store_price btn_search text-center">Submit</button>
                </div>
                <div class="col-md-12 m-t-30">
                    <table class="table">
                        <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                            
                            <tr>
                                <td style="width: 200px;"><?php echo e($item->name); ?></td>
                                <td style="width: 50px;"><?php echo e($item->price); ?>$</td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </table>
                </div>
            </div> 
        </div>
      </section>
    </div>    
    <script>            
        $(document).ready(function(){            
            $('.category_list').on('change', function() {
               
                var price = $(this).val();
                $(".input_price").val(price);
            });
            $(document).on('click','.btn_store_price',function(){
                var price = $(".input_price").val();
                var id = $(".category_list").find(':selected').data('id');
                if(price == "")
                {
                    return false;
                }
                else
                {                    
                    $.ajax({
                        url: '/api/admin/price',
                        type: 'get',
                        dataType: 'json',
                        data: {price:price,id:id},
                        success: function(data){
                            location.reload();
                        },
                        error: function(data){
                            location.reload();
                        }

                    });
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/admin/price.blade.php ENDPATH**/ ?>