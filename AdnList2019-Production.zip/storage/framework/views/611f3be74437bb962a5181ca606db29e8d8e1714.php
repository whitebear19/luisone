
<script>
    function get_cnt_messages() {
        $.ajax({
            url: "/api/get_cnt_messages",
            dataType: "json",
            type: "get",
            success: function(response){                    
                var cnt = response.data.length;                   
                if(cnt>0)
                {
                    $(".cnt_messages").html(cnt);
                    $(".cnt_messages").css("display","block");
                }
                else
                {
                    $(".cnt_messages").html("0");
                    $(".cnt_messages").css("display","none");
                }
            },
            error: function(response){

            }
        });
    }
    $(document).ready(function(){
        $(".cnt_messages").css("display","none");
        get_cnt_messages();
        setInterval(get_cnt_messages, 4000);
    });
    
</script><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/layouts/noti.blade.php ENDPATH**/ ?>