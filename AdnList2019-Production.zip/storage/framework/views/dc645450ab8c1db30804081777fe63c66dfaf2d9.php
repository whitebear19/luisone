<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">   
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="listing_category" class="">
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-left m-t-5">                                
                <P class="category_detail"><a href="<?php echo e(url('/')); ?>" class="show_navigate_home"><span><i class="fa fa-home"></i></span></a><span class="show_navigate_status"><?php echo e(trans('cat.post_submitted')); ?></span></P>            
            </div>
        </div>
    </div>
</section>

<section id="main" class="clearfix details-page">
    <div class="container">
        <div class="section slider">
            <div class="row">
                <div class="col-md-12 p-t-20">
                    <div class="final_part">
                        <?php if(Session::has('success')): ?>
                            
                            <p class="text-color-blue"><b><?php echo e(trans('cat.thankyou')); ?>! <?php echo e(Session::get('success')); ?></b></p>
                            
                        <?php endif; ?>
                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->email_verified_at): ?>
                                <p class="final-text">
                                    <?php echo e(trans('cat.final_text1')); ?>

                                </p>                                                               
                            <?php else: ?>
                                <p class="final-text">
                                    <?php echo e(trans('cat.final_text2')); ?>

                                </p>
                                <p class="text-color-red"> <?php echo e(trans('cat.final_text3')); ?></p>                            
                            <?php endif; ?>
                        <?php endif; ?>
                        <p class="final-text1">
                            <?php echo e(trans('cat.final_text4')); ?>

                        </p>
                        <br>
                        <ul>
                            <li>
                                <p> <?php echo e(trans('cat.final_text5')); ?></p>
                            </li>
                            <li>
                                <p> <?php echo e(trans('cat.final_text6')); ?></p>
                            </li>
                            <li>
                                <p> <?php echo e(trans('cat.final_text7')); ?></p>
                            </li>
                            <li>
                                <p> <?php echo e(trans('cat.final_text8')); ?></p>
                            </li>
                        </ul>
                        
                        <?php if(Auth::check()): ?>                                
                            <p class="final-text">
                                <?php echo e(trans('cat.final_text9')); ?>

                            </p>                           
                        <?php endif; ?>
                    </div>                        
                </div>	
            </div>				
        </div>
    </div>
</section>
<input type="hidden" class="current_page" value="final">
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/user/post_final.blade.php ENDPATH**/ ?>