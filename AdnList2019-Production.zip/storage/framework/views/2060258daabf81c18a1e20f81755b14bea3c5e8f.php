<?php $__env->startSection('title', __('Page Expired')); ?>


<?php $__env->startSection('page_custom'); ?>
    <div>
        <h1 class="error_title">Page Expired!</h1>        
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/errors/419.blade.php ENDPATH**/ ?>