<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/address_autofill.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>   
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="listing_category" class="">
        <div class="container">
            <div class="row">
                <div class="col-md-3 text-left m-t-5">                    
                    <P class="category_detail"><a href="<?php echo e(url('/')); ?>" class="show_navigate_home"><span><i class="fa fa-home"></i></span></a><span class="show_navigate_status"><a href="javascript:;"><?php if(!empty($cur_category) && ($cur_category != "all")): ?><?php echo e($cur_category->name); ?><?php else: ?> All Categories <?php endif; ?></a></span></P>
                    <div class="accordion">                        
                        <div class="panel-group" id="accordion">
                            <div class="panel-default panel-faq">                                
                                <div class="panel-heading active-faq">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#accordion-one"
                                        aria-expanded="true" class="">
                                        <h4 class="panel-title">Business Category<span class="pull-right"><i
                                                    class="fa fa-minus"></i></span></h4>
                                    </a>
                                </div>

                                <div id="accordion-one" class="panel-collapse collapse in" tabindex="0"
                                    aria-expanded="true" style="">
                                    
                                    <div class="panel-body custom_scroll" id="cat-scroll">                                        
                                        <?php if(!empty($all_category)): ?>
                                            <ul role="tablist" class="cs_category_view_list">
                                                    <li>
                                                        <form action="<?php echo e(route('category_view',['all','all'])); ?>" class="all_category_view_form" method="get">
                                                            <div class="all_category_view <?php if(empty($cur_subcategory)): ?> text-color-blue <?php endif; ?>">
                                                                <span class="fs-16 p-l-30"><b>All Categories</b></span>                                                                                                                            
                                                            </div>                                               
                                                        </form>
                                                    </li>
                                                <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li>
                                                        <a href="<?php echo e(route('category_view',[$item->id,'all'])); ?>"><span class="select cat_icon_style">
                                                            <img class="category_view_image" src="<?php echo e(asset($item->image)); ?>" alt="Images"></span>
                                                            <?php if($cur_category =="all"): ?>
                                                                <span class="" style="font-weight:600;letter-spacing:-0.2px"><?php echo e($item->name); ?></span>
                                                            <?php else: ?>
                                                                <?php if($cur_category->slug == $item->slug): ?> <span class="selected checked" style="letter-spacing:-0.2px"><?php echo e($item->name); ?></span> <?php else: ?> <span class="" style="font-weight:600;letter-spacing:-0.2px"><?php echo e($item->name); ?></span> <?php endif; ?> 
                                                            <?php endif; ?>
                                                        </a>
                                                    </li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </ul>
                                        <?php endif; ?>
                                    </div>
                                </div>                                
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-9 m-t-5">                    
                    <div class="search_form_listing">
                        <?php if($cur_category == "all"): ?>
                            <form action="<?php echo e(url('category_view',['all', 'all'])); ?>" class="search-form" method>
                        <?php else: ?>
                            <form action="<?php echo e(url('category_view',[$cur_category->id, $sub_category])); ?>" class="search-form" method>
                        <?php endif; ?>
                            <div class="row">
                                <div class="col-sm-4 search_p_r_0">
                                    <div class="m-t-4">                                                
                                        <input type="text" id="welcomelocation" class="form-control text-color-blue" name="location" value="<?php if(!empty($city)): ?><?php echo e($city); ?>, <?php echo e($state); ?>,<?php echo e("US"); ?> <?php endif; ?>">
                                        <input type="hidden" name="autofill_city" class="autofill_city" value="">
                                        <input type="hidden" name="search_city" class="search_city" value="<?php echo e($city); ?>">
                                        <input type="hidden" name="search_county" class="search_county" value="<?php echo e($county); ?>">
                                        <input type="hidden" name="search_state" class="search_state" value="<?php echo e($state); ?>">   
                                        <p style="font-size:12px;font-weight:600;margin-bottom: 0px;line-height: 18px;"><?php echo e($county); ?>&nbsp;County,<?php echo e($state); ?> Classifieds</p>                                  
                                    </div>
                                </div>    
                                <div class="col-sm-3">                                            
                                    <div class="m-t-4">                                                
                                        <input type="text" class="form-control auto_submit" name="search" placeholder="eg.cars" value="<?php echo e($search); ?>">
                                    </div>
                                </div>    
                                <div class="col-sm-3 search_p_l_0 search_p_r_0">
                                    <div class="m-t-4">                                                                                    
                                        <select name="sub_category" class="form-control sub_category text-color-blue">
                                            <option value="all" <?php if($sub_category == "all"): ?> selected <?php endif; ?> class="<?php if($sub_category == "all"): ?> text-color-red <?php endif; ?>">All <?php if($cur_category != "all"): ?><?php if($cur_category->slug == "Services"): ?><?php echo e(__('Services')); ?><?php elseif($cur_category->slug == "Sale"): ?><?php echo e(__('Sales')); ?><?php elseif($cur_category->slug == "Jobs"): ?><?php echo e(__('Jobs')); ?><?php elseif($cur_category->slug == "Rent"): ?><?php echo e(__('Rent/ Lease items')); ?><?php elseif($cur_category->slug == "Adaption"): ?><?php echo e(__('Pets')); ?><?php else: ?><?php echo e($cur_category->name); ?> <?php endif; ?> <?php endif; ?></option>
                                            <?php if(!empty($cur_subcategory)): ?>
                                                <?php $__currentLoopData = $cur_subcategory; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                            
                                                    <option value="<?php echo e($item['sub_categoryID']); ?>" <?php if($sub_category == $item['sub_categoryID']): ?> selected <?php endif; ?> class="<?php if($sub_category == $item['sub_categoryID']): ?> text-color-red <?php endif; ?>"> <?php echo e($item['sub_categoryName']); ?> </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                                            
                                                    <option value="<?php echo e($item->id); ?>" <?php if($cur_sel_category == $item->id): ?> selected <?php endif; ?> class="<?php if($cur_sel_category == $item->id): ?> text-color-red <?php endif; ?>">All <?php echo e($item->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </select>                                                
                                    </div>
                                </div>    
                                <div class="col-sm-2">
                                    <div class="m-t-4">                                               
                                        <div class="text-center">
                                            <div class="m-t-0" style="display:inline-block;">
                                                <button class="tablinks view_list text-color-green" type="button" data-value="list"><i class="fa fa-th-list"></i> </button>
                                                <button class="tablinks view_grid" type="button" data-value="grid"><i class="fa fa-th-large"></i> </button>
                                                <button class="tablinks view_col" type="button" data-value="col"><i class="fa fa-align-justify"></i> </button>                                                
                                            </div>                                            
                                        </div>                                                
                                    </div>
                                </div>
                            </div>                                                           
                        </form>
                    </div>    
                </div>
                <div class="col-md-9">
                    <!-- pagination  -->
                    <div class="text-center pagination_link" style="margin-top:-10px;">
                        <?php echo e($all_poster->appends(['city' => $city, 'search' => $search, 'sub_category' => $sub_category])->links()); ?>

                    </div>
                    <!-- pagination end  -->                    
                    <div id="Grid" class="tabcontent grid m-t-15" style="display:none;">
                        <div class="row">
                            <?php if(!empty($all_poster)): ?>
                                <?php $__currentLoopData = $all_poster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php  
                                        if(!empty(session('sub_cat')))
                                        {
                                            $sub_category = session('sub_cat');
                                        }   
                                        else
                                        {
                                            $sub_category = "all";
                                        }       
                                        $images = json_decode($item->post_image1);                                  
                                    ?>
                                    <div class="col-sm-4">
                                        <div class="post_wrap">
                                            <div class="post_img">
                                                <span class="like_post"><?php if(!empty($item->getcategoryname)): ?><?php echo e($item->getcategoryname->name); ?><?php else: ?> Deleted Category <?php endif; ?></span>
                                                <a class="get_pid" data_pid="<?php echo e($item->id); ?>" href="<?php echo e(url('category_view/detail',[$item->id, $sub_category])); ?>"><img style="width:100%;" class="" src="<?php if(!empty($images) && file_exists('upload/img/poster/lg/'.$images['0'])): ?><?php echo e(asset('upload/img/poster/lg/'.$images['0'])); ?> <?php else: ?> <?php echo e(asset('assets/images/listing/no_image.jpg')); ?> <?php endif; ?>" alt="image"></a>
                                            </div>
                                            <div class="post_info">
                                                <div class="post_info_title">
                                                    <h4><a class="get_pid" data_pid="<?php echo e($item->id); ?>" href="<?php echo e(url('category_view/detail',[$item->id, $sub_category])); ?>"> <span class="common_post_title"><?php echo e(substr($item->title,0,59)); ?></span> </a></h4>
                                                </div>
                                                <div class="post_meta">                                                    
                                                    <p class="left"><span><i class="fa fa-map-marker m-r-5"></i></span> <span class="location_time"><?php echo e($item->in_city); ?> <?php echo e($item->in_state); ?> <?php echo e($item->in_country); ?></span></p>
                                                    <p class="right location_time"> <i class="fa fa-dot-circle-o m-r-5"></i><?php echo e(substr($item->created_at,0,10)); ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if($all_poster->isEmpty()): ?>
                                <div class="row">                                    
                                    <div class="col-sm-12">
                                        <p class="text-color-blue" style="text-align:center;"><b>No post</b></p>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div id="List" class="tabcontent m-t-15" style="">
                        <div class="">
                            <ul class="p-l-0">
                                <?php if(!empty($all_poster)): ?>
                                    <?php $__currentLoopData = $all_poster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php                                                                              
                                            if(empty($sub_category))
                                            {
                                                $sub_category = "all";
                                            }      
                                            $images = json_decode($item->post_image1);   
                                        ?>
                                        <li style="list-style-type:none;">
                                            <div class="" style="border: 1px solid #e3e3e3; ">
                                                <div class="item-image">
                                                    <a href="<?php echo e(url('category_view/detail',[$item->id, $sub_category])); ?>" class="post_url get_pid" data_pid="<?php echo e($item->id); ?>">
                                                        <img src="<?php if(!empty($images) && file_exists('upload/img/poster/lg/'.$images['0'])): ?><?php echo e(asset('upload/img/poster/lg/'.$images['0'])); ?><?php else: ?> <?php echo e(asset('assets/images/listing/no_image.jpg')); ?><?php endif; ?>" alt="Image"
                                                            class="img-responsive">
                                                    </a>                                                    
                                                </div> 
                                                <div class="ad-info"> 
                                                    <h4 class="item-title"><a data_pid="<?php echo e($item->id); ?>" class="post_url get_pid" href="<?php echo e(url('category_view/detail',[$item->id, $sub_category])); ?>"><span class="common_post_title"><?php echo e(substr($item->title,0,79)); ?></span></a></h4>
                                                    <div class="item-cat">
                                                        <span><?php if(!empty($item->getcategoryname)): ?><?php echo e($item->getcategoryname->name); ?><?php else: ?> Deleted Category <?php endif; ?></span>                                
                                                    </div>
                                                    <div class="item-cat location_time">
                                                        <span class="m-r-20"><i class="fa fa-dot-circle-o m-r-5"></i><?php if(empty($cur_subcategory)): ?><?php echo e(substr($item->created_at,0,10)); ?> <?php else: ?><?php echo e(substr($item->created_at,0,10)); ?><?php endif; ?></span> 
                                                        <span><i class="fa fa-map-marker m-r-5"></i><?php echo e($item->in_city); ?> <?php echo e($item->in_state); ?> <?php echo e($item->in_country); ?></span>                                   
                                                    </div>
                                                </div>
                                            </div>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            </ul>                            
                        </div>
                        <?php if($all_poster->isEmpty()): ?>
                            <div class="row">                                    
                                <div class="col-sm-12">
                                    <p class="text-color-blue" style="text-align:center;"><b>No post</b></p>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                    <div id="Col" class="tabcontent  m-t-15" style="display:none;">
                        <!-- ad-item -->
                        <div class="row table-responsive resp_margin_auto" style="min-height: 100px">
                            <div class="col-md-12">
                                <?php if(count($all_poster)>0): ?>                                
                                    <ul class="normal_ul">
                                        <?php $__currentLoopData = $all_poster; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>   
                                            <?php
                                                $temp_time = strtotime($cur_date)-strtotime($item->created_at);
                                                $different_day  = floor($temp_time/(60*60*24));
                                                $different_hour = floor($temp_time/(60*60));
                                                $different_min  = ceil($temp_time/60);
                                                if($different_day>0)
                                                {
                                                    $different_time = $different_day." days ago";
                                                }
                                                else
                                                {
                                                    if($different_hour>0)
                                                    {
                                                        $different_time = $different_hour." hrs ago";
                                                    }
                                                    else
                                                    {
                                                        if($different_min<1)
                                                        {
                                                            $different_time = "1 min ago";
                                                        }
                                                        else
                                                        {
                                                            $different_time = $different_min." min ago";
                                                        }                                                
                                                    }
                                                }
                                                if(empty($sub_category))
                                                {
                                                    $sub_category = "all";
                                                }      
                                            ?>                                                                 
                                            <li>
                                                <a href="<?php echo e(url('category_view/detail',[$item->id, $sub_category])); ?>" data_pid="<?php echo e($item->id); ?>" class="get_pid text-justify M_disp_flex normal-title">
                                                    <div class="item-image"><label class="col-black m-r-10 fs-14"><?php echo e(substr($item->created_at,0,10)); ?></label></div>
                                                    <div class="ad-info">
                                                        <p class="col-title common_post_title" style="line-height:25px;"><?php echo e(substr($item->title,0,79)); ?> </p>
                                                        <p class="left fs-14 text-color-grey location_time" style="line-height:12px;font-weight:400;"><span><i class="fa fa-map-marker price"></i></span> <span><?php echo e($item->in_city); ?> <?php echo e($item->in_state); ?> <?php echo e($item->in_country); ?></span></p>
                                                    </div>                                                    
                                                </a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                       
                                    </ul>                                    
                                <?php endif; ?>
                                <?php if($all_poster->isEmpty()): ?>                                                      
                                    <p class="text-color-blue"  style="text-align:center;"><b>No post</b></p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <!-- pagination  -->
                    <div class="text-center">
                        <?php echo e($all_poster->appends(['city' => $city, 'search' => $search, 'sub_category' => $sub_category])->links()); ?>

                    </div>
                    <!-- pagination end  -->
                </div>
            </div>
        </div>
    </section>

    
    <section id="listing_banner" class="section_padding m-t-30">
        <div class="container-fluid fluid-padding">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="m-b-20">Do you have something to post?</h2>
                    <h5 class="m-b-20">Post your ad for free on adnlist.com</h5>
                    <?php if(Auth::check()): ?>
                        <a href="<?php echo e(route('create_post')); ?>" class="btn">Post Your Ad</a>
                    <?php else: ?>
                        <a href="javascript:;" data-toggle="modal" data-value="login" data-target="#signModal" class="btn">Post Your Ad</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </section>
    <script>
        $(document).ready(function(){
            $(".all_category_view").click(function(){                
                $(".all_category_view_form").submit();               
            });
        });
    </script>
<?php $__env->stopSection(); ?>
    
	
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/user/category_view.blade.php ENDPATH**/ ?>