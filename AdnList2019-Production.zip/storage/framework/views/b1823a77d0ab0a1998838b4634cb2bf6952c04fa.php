<?php $__env->startSection('content'); ?>

<div class="row">    
    <div class="col-sm-12 col-xs-12  m-t-20">

        <div class="footer_edit_form">
            <div class="footer_edit_form_nav">
                <ul>
                    <li>                        
                        <a class="btn_termsOfUse btn_normal_nav <?php if($nav_name == 'privacy'): ?> active <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"privacy")); ?>">Privacy Policy</a>
                    </li>
                    <li>                        
                        <a class="btn_termsOfUse btn_normal_nav <?php if($nav_name == 'terms'): ?> active <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"terms")); ?>">Terms of use</a>
                    </li>
                    
                    <li>                        
                        <a class="btn_termsOfUse btn_normal_nav <?php if($nav_name == 'faq'): ?> active <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"faq")); ?>">Faq</a>
                    </li>   
                    <li>
                        <a class="btn_termsOfUse btn_normal_nav <?php if($nav_name == 'prohibited'): ?> active <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"prohibited")); ?>">Prohibited</a>
                    </li>  
                    <li>
                        <a class="btn_termsOfUse btn_normal_nav <?php if($nav_name == 'postingtips'): ?> active <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"postingtips")); ?>">Posting Tips</a>
                    </li>   
                    <li>
                        <a class="btn_termsOfUse btn_normal_nav <?php if($nav_name == 'careers'): ?> active <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"careers")); ?>">Careers</a>
                    </li> 
                    <li>
                        <a class="btn_termsOfUse btn_normal_nav <?php if($nav_name == 'payment'): ?> active <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"payment")); ?>">Payment Policy</a>
                    </li>       
                    <li>
                        <a class="btn_termsOfUse btn_normal_nav <?php if($nav_name == 'about'): ?> active <?php endif; ?>" href="<?php echo e(url('admin/footer_edit',"about")); ?>">About</a>
                    </li>                            
                </ul>  
            </div>
            <div class="footer_edit_form_body">
                <div class="termsOfUse common_body">
                    <form action="<?php echo e(route('store_footer_content')); ?>" method="post">
                        <?php echo csrf_field(); ?>                        
                        <input type="hidden" name="nav_name" value="<?php echo e($nav_name); ?>">
                        <textarea name="terms" class="terms">
                            <?php if($nav_name == "terms"): ?>
                                <?php echo e($temp->footer_terms); ?>

                            <?php elseif($nav_name == "privacy"): ?>
                                <?php echo e($temp->footer_privacy); ?>

                            <?php elseif($nav_name == "faq"): ?>
                                <?php echo e($temp->footer_faq); ?>

                            <?php elseif($nav_name == "prohibited"): ?>
                                <?php echo e($temp->footer_prohibited); ?>

                            <?php elseif($nav_name == "postingtips"): ?>
                                <?php echo e($temp->footer_postingtips); ?>

                            <?php elseif($nav_name == "careers"): ?>
                                <?php echo e($temp->footer_careers); ?>

                            <?php elseif($nav_name == "payment"): ?>
                                <?php echo e($temp->footer_payment); ?>

                            <?php elseif($nav_name == "about"): ?>
                                <?php echo e($temp->footer_about); ?>

                            <?php endif; ?>
                        </textarea>
                        <div class="text-center m-t-20">
                            <button class="btn_common">Submit</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>  
</div>
<script>         
    $(".terms").summernote('code');   
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/admin/admin_footer_edit.blade.php ENDPATH**/ ?>