<?php $__env->startSection('title', __('Not Found')); ?>

<?php $__env->startSection('page_custom'); ?>
    <div>
        <h1 class="error_title">We looked really hard!</h1>
        <p class="error_content">500 Server Error!</p>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('errors::minimal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/errors/500.blade.php ENDPATH**/ ?>