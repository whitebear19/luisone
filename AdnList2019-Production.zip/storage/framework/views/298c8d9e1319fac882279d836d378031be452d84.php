<?php $__env->startSection('content'); ?>

<section class="m-t-60">
    <div class="row">
        <div class="col-md-12 text-center">
            <h2 class="home_title">What is Prohibited</h2>
        </div>
    </div>
</section>

<section id="main" class="clearfix contact-us">
    <div class="container">
        <div class="contactus m-t-20">                   
            <h4 class="title text-center">Adnlist</h4>
            <p class="text-center fs-18 text-color-black">Last Updated: <span><?php echo e(substr($footer_data->updated_at,0,10)); ?></span></p>
            <h6>Prohibited</h6>
            <div class="corporate-info">
                <div class="row">                    
                    <div class="col-sm-12">
                        <?php if(!empty($footer_data->footer_prohibited)): ?>
                        <?php echo $footer_data->footer_prohibited; ?>

                        <?php endif; ?>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/prohibited.blade.php ENDPATH**/ ?>