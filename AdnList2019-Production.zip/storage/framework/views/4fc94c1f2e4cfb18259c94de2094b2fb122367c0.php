<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/accordion.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/accordion.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<section class="m-t-60">
    <div class="row">
        <div class="col-md-12 text-center">
            <h2 class="home_title">Faqs</h2>
        </div>
    </div>
</section>
<section id="main" class="clearfix contact-us">
    <div class="container">
        <div class="contactus m-t-20">                   
            <h4 class="title text-center">Adnlist</h4>
            <p class="text-center fs-18 text-color-black">Last Updated: <span><?php echo e(substr($footer_data->date_faq,0,10)); ?></span></p>
            <h6>FAQ</h6>
            <div class="corporate-info">
                <div class="row">                    
                    <div class="col-sm-12">
                        <?php if($footer_data->footer_faq): ?>
                        <?php echo $footer_data->footer_faq; ?>

                        <?php endif; ?>
                    </div> 
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/faq.blade.php ENDPATH**/ ?>