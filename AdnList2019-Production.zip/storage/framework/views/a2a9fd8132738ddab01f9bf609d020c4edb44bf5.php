<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section id="main" class="clearfix admin-page">
		<div class="container">
			<div class="row text-center">							
				<div class="col-sm-8 col-sm-offset-2 col-md-6 col-md-offset-3">
					<div class="user-account">
						
						<h2><b>Admin Login</b></h2>
						
						<form action="<?php echo e(route('login')); ?>" method="post">
                        <?php echo csrf_field(); ?>
							<div class="form-group m-b-30">
                                <div class="form-group has-feedback">
								    <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Admin Email" autofocus>
                                    <span class="form_icon_pos"><i class="fa fa-envelope"></i></span>
                                </div>
                                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                    <span class="invalid-feedback3" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
							<div class="form-group m-b-30">
                                <div class="form-group has-feedback">
                                    <input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required placeholder="Password" autocomplete="current-password">
                                    <span class="form_icon_pos"><i class="fa fa-lock"></i></span>
                                </div>
                                <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                    <span class="invalid-feedback3" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
							</div>
							<button type="submit" href="#" class="btn btn_login"><span><i class="fa fa-sign-in"></i></span> Login</button>
                            
                        </form>
					</div>					
				</div>
			</div>
		</div>
	</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.userlogin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/admin/adminlogin.blade.php ENDPATH**/ ?>