<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section id="banner" class="parallex-bg">
    <div class="container cs_home_border">
        <div class="row justify-content-center">
            <div class="col-sm-8 col-sm-offset-2 col-md-8 col-md-offset-2">           

                <div class="user-account text-center">     
                    
                    <?php if(session('status')): ?>                    
                        <div class="alert alert-success alert-dismissible m-t-20" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <strong>Success!</strong> <span><?php echo e(session('status')); ?></span>
                        </div>
                    <?php endif; ?>              
                    <h2 class="p-t-10 p-b-10"><b><?php echo e(__('Reset Password')); ?></b></h2>

                    
                    <form method="POST" action="<?php echo e(route('password.email')); ?>">
                    <?php echo csrf_field(); ?>
                        <div class="form-group m-b-30">
                            <div class="form-group has-feedback">                            
                                <input id="email" type="email" class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" placeholder="Your Registered Email" autofocus>
                                <span class="form_icon_pos"><i class="fa fa-envelope"></i></span>
                            </div>
                            <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                <div class="email_alert">
                                    <span class="" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                </div>
                                
                            <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                        </div>
                        
                        
                        <div class="form-group row mb-0">
                            <div class="col-md-12 offset-md-4 text-center">
                                <button type="submit" class="btn btn-primary" style="width:100%;">
                                    <?php echo e(__('Send Password Reset Link')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                    
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/auth/passwords/email.blade.php ENDPATH**/ ?>