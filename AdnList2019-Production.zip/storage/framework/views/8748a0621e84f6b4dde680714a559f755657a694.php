<?php $__env->startSection('script'); ?>
<script src="<?php echo e(asset('admin/dist/js/country.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('style'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

 
 <div class="content-wrapper">    
    <section class="content-header">
      <h3>Country</h3>      
    </section>
    <section class="content">
      <div class="row">       
        <div class="col-xs-12">
            <div class="box">                
                <div class="box-body">
                    <div class="row">                        
                        <div class="col-md-12">
                        <?php if(empty($all_country)): ?> 
                            <button class="btn btn-primary btn_register_country btn-sm">
                                Country Register
                            </button>
                        <?php else: ?>
                            <div class="new_category_body m-t-40">
                                <h4><b>Registered Country</b></h4>
                                  
                                <?php $i=0; ?>                                 
                                <table class="table">
                                    <?php $__currentLoopData = $all_country; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php $i=$i+1 ?>
                                        <tr>
                                            <td><span><?php echo e($i); ?></span></td>
                                            <td><span><?php echo e($item->countryname); ?></span></td>
                                            <td><span>+<?php echo e($item->countrycode); ?></span></td>
                                            <td><img style="width:30px;" src="<?php echo e($item->countryflag); ?>" alt=""></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </div>
                        <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div> 
      </div>     
    </section>   
  </div>  
  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/admin/country.blade.php ENDPATH**/ ?>