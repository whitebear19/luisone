<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.user_profile_header_normal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="main" class="clearfix  ad-profile-page">
    <div class="container resp_padding_0">
    
        <?php echo $__env->make('layouts.user_profile_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="profile">
            <div class="row">
                <div class="col-sm-9">
                    <form action="<?php echo e(route('user_profile_update')); ?>" method="post" class="profile_form" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                        <div class="user-pro-section">
                                                          
                            <div class="profile-details section">
                                <?php if(session('error')): ?>
                                    <div class="alert alert-success alert-dismissible" role="alert">
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <strong><?php echo e(trans('message.alert_warning')); ?>!</strong> <span><?php echo e(session('error')); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success alert-dismissible" role="alert">
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                                        <strong><?php echo e(trans('message.alert_success')); ?>!</strong> <span><?php echo e(session('success')); ?></span>
                                    </div>
                                <?php endif; ?>
                                
                                <h2><?php echo e(trans('message.userprofile_details')); ?></h2>
                                <!-- form -->
                                
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.placeholder_fname')); ?></label>
                                    <input type="text" name="fname" class="form-control" value="<?php echo e(Auth::user()->fname); ?>">
                                </div>
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.placeholder_lname')); ?></label>
                                    <input type="text" name="lname" class="form-control" value="<?php echo e(Auth::user()->lname); ?>">
                                </div>
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.userprofile_email')); ?></label>
                                    <input type="email" name="email" class="form-control" readonly value="<?php echo e(Auth::user()->email); ?>">
                                </div>
                                
                                <div class="form-group m-b-30">
                                    <label for="name-three"><?php echo e(trans('message.userprofile_phonecode')); ?></label>
                                    <input type="tel"  class="form-control phonecode" name="phonecode" maxlength="4" value="<?php if(!empty(Auth::user()->phone_code)): ?><?php echo e(Auth::user()->phone_code); ?><?php endif; ?>">
                                </div>
                                <div class="form-group m-b-30">
                                    <label for="name-three"><?php echo e(trans('message.userprofile_mobile')); ?></label>
                                    <input type="tel"  class="form-control" name="phone" maxlength="10" value="<?php if(!empty(Auth::user()->phone)): ?><?php echo e(Auth::user()->phone); ?><?php endif; ?>">
                                </div>
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.city')); ?></label>
                                    <input class="form-control" name="city" id="profile_city" value="<?php if(!empty(Auth::user()->city)): ?><?php echo e(Auth::user()->city); ?><?php endif; ?>">
                                </div>	
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.state')); ?></label>
                                    <input class="form-control" name="state" id="profile_state" value="<?php if(!empty(Auth::user()->state)): ?><?php echo e(Auth::user()->state); ?><?php endif; ?>">
                                </div>	
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.country')); ?></label>
                                    <input class="form-control" name="country" id="profile_country" value="<?php if(!empty(Auth::user()->country)): ?><?php echo e(Auth::user()->country); ?><?php endif; ?>">
                                </div>	
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.address')); ?></label>
                                    <input class="form-control" name="address" maxlength="30" value="<?php if(!empty(Auth::user()->address)): ?><?php echo e(Auth::user()->address); ?><?php endif; ?>">
                                </div>	
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.zip')); ?></label>
                                    <input class="form-control zip_code number_field" name="zip" maxlength="5"  value="<?php if(!empty(Auth::user()->zip)): ?><?php echo e(Auth::user()->zip); ?><?php endif; ?>">
                                </div>	
                                <div class="form-group m-b-30">
                                    <label><?php echo e(trans('message.userprofile_you')); ?></label>
                                    <select class="form-control" name="type">
                                        <option value="" ></option>
                                        <option value="2" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 2): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_seller')); ?></option>
                                        <option value="1" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 1): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_real')); ?></option>
                                        <option value="3" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 3): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_recruiter')); ?></option>
                                        <option value="4" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 4): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_service')); ?></option>
                                        <option value="5" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 5): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_individual')); ?></option>
                                        <option value="6" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 6): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_property')); ?></option>
                                        <option value="7" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 7): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_event')); ?></option>
                                        <option value="8" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 8): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_instructor')); ?></option>
                                        <option value="9" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 9): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_advocate')); ?></option>
                                        <option value="10" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 10): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_contractor')); ?></option>
                                        <option value="11" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 11): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_localagent')); ?></option>
                                        <option value="12" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 12): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_beautician')); ?></option>
                                        <option value="13" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 13): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_doctor')); ?></option>
                                        <option value="14" <?php if(!empty(Auth::user()->type) && Auth::user()->type == 14): ?> selected <?php endif; ?> ><?php echo e(trans('message.userprofile_you_cpa')); ?></option>
                                    </select>
                                </div>					
                            </div>
                            
                            <div class="preferences-settings section m-t-20 m-b-20" style="text-align:center;">
                                <button type="button" class="btn btn-green m-r-30 btn_profile_submit"><?php echo e(trans('message.userprofile_updateprofile')); ?></button>
                                <a href="" class="btn btn-cancel"><?php echo e(trans('message.cancel')); ?></a>	
                            </div>                            
                        </div>
                    </form>                     
                </div>

                <div class="col-sm-3 text-center">
                    <?php echo $__env->make('layouts.user_profile_recommended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                   
                </div>
            </div>
        </div>				
    </div>
</section>
<script>
    var autocomplete;
    
    var map = null;
    function fillInAddress() { 
        
        var temp = $("#profile_city").val();        
        var location = temp.split(',');           
        if(location.length > 2)
        {            
            $("#profile_city").val(location[0]);
            $("#profile_state").val(location[1]);
            $("#profile_country").val(location[2]);
        }
        else
        {            
            $("#profile_state").val("");
            $("#profile_country").val("");
            $("#profile_city").addClass("red_border");
            alert("Please use the auto address input function. And confirm city name.");
            $("#profile_city").val("");
        }
       
        var place = autocomplete.getPlace(); 
        var latitude = place.geometry.location.lat(); 
        var longitude = place.geometry.location.lng();
        $(".latitude").val(latitude);
        $(".longitude").val(longitude);
        var uluru = {lat: latitude, lng: longitude};        

        radius = new google.maps.Circle({map: map,
                radius: 100,
                center: uluru,
                fillColor: '#777',
                fillOpacity: 0.1,
                strokeColor: '#AA0000',
                strokeOpacity: 0.8,
                strokeWeight: 2,
                draggable: true,    // Dragable
                editable: true      // Resizable
            });

            
        map.panTo(new google.maps.LatLng(latitude,longitude));        
    }
    

    function initMap() {
        
       
        autocomplete = new google.maps.places.Autocomplete(document.getElementById('profile_city'), {types: ['(cities)']}); 
        
        autocomplete.addListener('place_changed', fillInAddress);
       
    }
    
</script>
<script>
    $(".zip_code").on("keypress keyup blur",function (event) {    
        $(this).val($(this).val().replace(/[^\d].+/, ""));
         if ((event.which < 48 || event.which > 57)) {
             event.preventDefault();
        }
        $(this).removeClass("red_border");
    });

    $(".number_field").on("keypress keyup blur",function (event) {    
        $(this).val($(this).val().replace(/[^\d].+/, ""));
         if ((event.which < 48 || event.which > 57)) {
             event.preventDefault();
        }        
    });    

    $(".btn_profile_submit").on("click", function(){
        $(".profile_form").submit();
    })
    
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/user/user_profile.blade.php ENDPATH**/ ?>