<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.user_profile_header_normal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="main" class="clearfix  ad-profile-page">
    <div class="container resp_padding_0">
    
        <?php echo $__env->make('layouts.user_profile_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="profile">
            <div class="row">
                <div class="col-sm-9">  
                    <?php if(session('error')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <strong>Warning!</strong> <span><?php echo e(session('error')); ?></span>
                        </div>
                    <?php endif; ?>
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible" role="alert">
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                            <strong>Success!</strong> <span><?php echo e(session('success')); ?></span>
                        </div>
                    <?php endif; ?>                 
                    <form action="<?php echo e(route('changePassword')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                        <div class="change-password section">
                            <h2>Change password</h2>
                            
                            <div class="form-group m-t-40 m-b-40">
                                <label>Old Password</label>
                                <input type="password" class="form-control" name="currentpassword" autocomplete="off" required>
                            </div>
                            
                            <div class="form-group m-b-40">
                                <label>New password</label>
                                <input type="password" class="form-control" name="password" autocomplete="off" required>	
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block">
                                        <strong style="color:red;font-size:1.5rem;font-weight:400;"><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                            
                            <div class="form-group m-b-40">
                                <label>Confirm password</label>
                                <input type="password"  name="password_confirmation" class="form-control" autocomplete="off" required>
                            </div>
                            <div class="form-group" style="text-align:center;">
                                <button class="btn m-t-20 btn-green">Change Password</button>		
                            </div>											
                        </div>
                    </form>
                </div>

                <div class="col-sm-3 text-center">
                    <?php echo $__env->make('layouts.user_profile_recommended', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>                    
                </div>
            </div>
        </div>				
    </div>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/user/user_change_password.blade.php ENDPATH**/ ?>