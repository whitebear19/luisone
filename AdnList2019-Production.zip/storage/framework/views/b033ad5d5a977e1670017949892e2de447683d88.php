<?php $__env->startSection('content'); ?>


<section id="banner" class="parallex-bg">
	<div class="container cs_home_border">		
		<div class="row">
			<div class="col-md-7">
				<div class="intro_text div_zindex">	
					<h1 class="cs_home_main_title"><?php echo e(trans('message.home_title')); ?></h1>
					<div class="search_form_warp">
						<form action="<?php echo e(url('category_view',['all', 'all'])); ?>" class="homesearchTolist" method="">
							<ul>
								<li class="cs_home_search_location_fixed_width">
									<div class="form-group m_resp_mb_25">						
									<input type="text" class="form-control" id="welcomelocation" name="location" placeholder="<?php echo e(trans('message.home_placeholder_entercity')); ?>" value="<?php if(session('city') == "all" || session('city') == ""): ?> <?php echo e("All cities"); ?> <?php else: ?> <?php echo e(session('city')); ?>, <?php echo e(session('state_a')); ?> , <?php echo e(session('country')); ?> <?php endif; ?>">										
									<p class="cs_home_added_county" style="font-weight:600;"><span class="cs_home_show_county"><?php if(!empty(session('county'))): ?> <?php echo e(session('county')); ?> <?php echo e(trans('message.county')); ?> , <?php echo e(session('state_a')); ?> <?php endif; ?></span><span>&nbsp;<?php echo e(trans('message.classifieds')); ?></span></p>

										<input type="hidden" name="homepage" value="home">
										<input type="hidden" name="search_city" class="search_city" value="<?php if(!empty(session('city'))): ?> <?php echo e(session('city')); ?><?php endif; ?>">
                                        <input type="hidden" name="search_county" class="search_county" value="<?php if(!empty(session('county'))): ?> <?php echo e(session('county')); ?> <?php else: ?> <?php echo e($county); ?><?php endif; ?>">
                                        <input type="hidden" name="search_state" class="search_state" value="<?php if(!empty(session('state_a'))): ?> <?php echo e(session('state_a')); ?> <?php else: ?> <?php echo e($state); ?><?php endif; ?>">             
									</div>		
								</li>
								<li class="cs_home_search_width">
									<div class="form-group">
									<input type="text" class="form-control" name="search" placeholder="<?php echo e(trans('message.home_enter_searchword')); ?>">
									</div>
								</li>
								<li>
									<div class="form-group search_btn">
										<input type="button" value="Search" style="height:38px;" class="btn btn-block btn-green btn-home-search">
									</div>
								</li>
							</ul>							
						</form>
					</div>
				</div>
				<div class="cs_home_category_warp">	
					<ul>
						<?php if(empty(!$all_category)): ?>
							<?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<li>									
									<a href="<?php echo e(url('category_view',[$item['0'], 'all'])); ?>">
										<div class="category_icon">
											<div class="category_icon_area category_icon_position<?php echo e($item['0']); ?>">
												<div class="category_icon_background">
												</div>												
											</div>											
											<div class="category_name_area">
												<p class="" title="<?php echo e($item['1']); ?>"><b><?php echo e($item['1']); ?></b></p>
											</div>																			
										</div>											
									</a>									
								</li>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>				
					</ul>	
				</div>
			</div>
			<div class="col-md-5">
				<div class="" style="min-height:130px; display: flex;justify-content: center;align-items: center;">	
					<div>						
						<div class="search_form_warp cs_home_professional_nav">						
							<ul>
								<li>
									<p>
										<span>
											<svg style=" height:15px;width:15px" aria-hidden="true" focusable="false" data-prefix="far" data-icon="user" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" class="svg-inline--fa fa-user fa-w-14 fa-3x"><path fill="currentColor" d="M313.6 304c-28.7 0-42.5 16-89.6 16-47.1 0-60.8-16-89.6-16C60.2 304 0 364.2 0 438.4V464c0 26.5 21.5 48 48 48h352c26.5 0 48-21.5 48-48v-25.6c0-74.2-60.2-134.4-134.4-134.4zM400 464H48v-25.6c0-47.6 38.8-86.4 86.4-86.4 14.6 0 38.3 16 89.6 16 51.7 0 74.9-16 89.6-16 47.6 0 86.4 38.8 86.4 86.4V464zM224 288c79.5 0 144-64.5 144-144S303.5 0 224 0 80 64.5 80 144s64.5 144 144 144zm0-240c52.9 0 96 43.1 96 96s-43.1 96-96 96-96-43.1-96-96 43.1-96 96-96z" class=""></path></svg>
										</span>
										<span><?php echo e(trans('message.home_create_an_account')); ?></span>
									</p>
								</li>
								<li>
									<p>
										<span>
											<svg style="height:15px;width:15px;" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="upload" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-upload fa-w-16 fa-3x"><path fill="currentColor" d="M296 384h-80c-13.3 0-24-10.7-24-24V192h-87.7c-17.8 0-26.7-21.5-14.1-34.1L242.3 5.7c7.5-7.5 19.8-7.5 27.3 0l152.2 152.2c12.6 12.6 3.7 34.1-14.1 34.1H320v168c0 13.3-10.7 24-24 24zm216-8v112c0 13.3-10.7 24-24 24H24c-13.3 0-24-10.7-24-24V376c0-13.3 10.7-24 24-24h136v8c0 30.9 25.1 56 56 56h80c30.9 0 56-25.1 56-56v-8h136c13.3 0 24 10.7 24 24zm-124 88c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20zm64 0c0-11-9-20-20-20s-20 9-20 20 9 20 20 20 20-9 20-20z" class=""></path></svg>
										</span>
										<span>
											<?php echo e(trans('message.home_publish_your_post')); ?>

										</span>
									</p>
								</li>
								<li>
									<p>
										<span>
											<svg style="height:15px;width:15px;" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="reply-all" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 576 512" class="svg-inline--fa fa-reply-all fa-w-18 fa-3x"><path fill="currentColor" d="M136.309 189.836L312.313 37.851C327.72 24.546 352 35.348 352 56.015v82.763c129.182 10.231 224 52.212 224 183.548 0 61.441-39.582 122.309-83.333 154.132-13.653 9.931-33.111-2.533-28.077-18.631 38.512-123.162-3.922-169.482-112.59-182.015v84.175c0 20.701-24.3 31.453-39.687 18.164L136.309 226.164c-11.071-9.561-11.086-26.753 0-36.328zm-128 36.328L184.313 378.15C199.7 391.439 224 380.687 224 359.986v-15.818l-108.606-93.785A55.96 55.96 0 0 1 96 207.998a55.953 55.953 0 0 1 19.393-42.38L224 71.832V56.015c0-20.667-24.28-31.469-39.687-18.164L8.309 189.836c-11.086 9.575-11.071 26.767 0 36.328z" class=""></path></svg>
										</span>
										<span>
											<?php echo e(trans('message.home_get_response')); ?>

										</span>									
									</p>
								</li>
							</ul>
						</div>
					</div>					
				</div>
				<?php if(session('sentlink')): ?>
					<div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<strong><?php echo e(trans('message.alert_warning')); ?>!</strong> <span><?php echo e(session('sentlink')); ?></span>
					</div>
				<?php endif; ?>
				<div class="cs_home_category_warp" style="display:block;">	
					<h3 class="cs_home_professional_title"><?php echo e(trans('message.home_latest_news')); ?></h3>
					<?php if(count($cur_ads)<1): ?>
						<div class="cs_home_latest_news">
							<div>
								<p class="cs_home_latest_news_title"><?php echo e(trans('message.home_latest_news_text')); ?> promote@adnlist.com</p>
							</div>						
						</div>
					<?php else: ?>
						<div class="cs_home_latest_news_real">
							<div id="myCarousel" class="carousel slide" data-ride="carousel">
															  
								<!-- Wrapper for slides -->
								<?php $i=1 ?>
								<div class="carousel-inner" style="width:100%;">
									<?php $__currentLoopData = $cur_ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<div class="item <?php if($i == "1"): ?> active <?php endif; ?>">
											<img src="<?php if(!empty($item->image)): ?><?php echo e(asset('upload/img/adver/'.$item->image)); ?> <?php else: ?> <?php echo e(asset('assets/images/back.jpg')); ?> <?php endif; ?>" alt="advertisment image">
											<div class="carousel-caption" style="right: 0%;left: 0%;padding-bottom: 0px;height: 95%;float:left;">												
												<?php if(!empty($item->type)): ?>
												<span class="cs_home_business_type"><?php echo e($item->type); ?></span>
												<?php endif; ?>
												<?php if(!empty($item->logo)): ?>
													<span class="cs_home_business_logo">													
														<img style="width:40px;" src="<?php echo e(asset('upload/img/adver/'.$item->logo)); ?>" alt="logo image">
													</span>
												<?php endif; ?>
												<?php if(empty($item->image)): ?>
													<?php if(!empty($item->body)): ?>
														<p class="cs_home_business_content" style="color: black;padding:20px 5px 5px 5px;">													
															<?php echo e($item->body); ?>

														</p>
													<?php endif; ?>
												<?php endif; ?>
												<a href="<?php echo e(route('news_detail',$item->id)); ?>" class="btn_cs_view_more btn btn-blue" style="padding:3px 5px;">Click for more</a>
												
											</div>
										</div>
										<?php $i=$i+1 ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>									
								</div>
							  
								<!-- Left and right controls -->
								<a class="left carousel-control" style="left:0px;" href="#myCarousel" data-slide="prev" style="left:0px;">
									<span class="">
										<svg aria-hidden="true" style="width:15px;" focusable="false" data-prefix="fas" data-icon="angle-left" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="svg-inline--fa fa-angle-left fa-w-8 fa-3x"><path fill="currentColor" d="M31.7 239l136-136c9.4-9.4 24.6-9.4 33.9 0l22.6 22.6c9.4 9.4 9.4 24.6 0 33.9L127.9 256l96.4 96.4c9.4 9.4 9.4 24.6 0 33.9L201.7 409c-9.4 9.4-24.6 9.4-33.9 0l-136-136c-9.5-9.4-9.5-24.6-.1-34z" class=""></path></svg>
									</span>									
								</a>
								<a class="right carousel-control" style="" href="#myCarousel" data-slide="next">
									<span class="">
										<svg aria-hidden="true" style="width:15px;" focusable="false" data-prefix="fas" data-icon="angle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 512" class="svg-inline--fa fa-angle-right fa-w-8 fa-3x"><path fill="currentColor" d="M224.3 273l-136 136c-9.4 9.4-24.6 9.4-33.9 0l-22.6-22.6c-9.4-9.4-9.4-24.6 0-33.9l96.4-96.4-96.4-96.4c-9.4-9.4-9.4-24.6 0-33.9L54.3 103c9.4-9.4 24.6-9.4 33.9 0l136 136c9.5 9.4 9.5 24.6.1 34z" class=""></path></svg>
									</span>									
								</a>
								
							</div>			
						</div>
					<?php endif; ?>
				</div>
			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-6">
				<p class="text-center fs-14"><b>
					<span><?php echo e(trans('business.hometext1')); ?></span>
					<a href="" class="text-color-blue"><?php echo e(trans('business.registernow')); ?></a></b>
				</p>
				<a href="" class="text-color-blue fs-16"><b><?php echo e(trans('business.findbusiness')); ?></b></a>
			</div>
			<div class="col-md-6">

			</div>
		</div>
		<br>
		<div class="row">
			<div class="col-md-12">
				<div class="business_item">
					<ul>
						<li>
							<a href="<?php echo e(url('professional_view/1/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Real Estate</p>
									<p class="business_detail">buy,sell,rent</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/2/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Home Improvement</p>
									<p class="business_detail">Contractors Interior</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/3/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Pets</p>
									<p class="business_detail">cat,dog</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/4/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Lawyers/ Attorny Services</p>
									<p class="business_detail">buy,sell,rent</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/1/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Baby care</p>
									<p class="business_detail">apparels, gear, toys</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/2/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Event</p>
									<p class="business_detail">party</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/3/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Pets</p>
									<p class="business_detail">salons grooming, wets</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/4/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Lawyers/ Attorny Services</p>
									<p class="business_detail">buy,sell,rent</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/1/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Baby care</p>
									<p class="business_detail">apparels, gear, toys</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/2/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Event</p>
									<p class="business_detail">birthday, wedding</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/3/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Pets</p>
									<p class="business_detail">salons grooming, wets</p>
								</div>
							</a>
						</li>
						<li>
							<a href="<?php echo e(url('professional_view/4/1')); ?>">
								<img src="<?php echo e(asset('upload/img/business/1.png')); ?>" alt="">
								<div class="business_note">
									<p class="business_title">Lawyers/ Attorny Services</p>
									<p class="business_detail">buy,sell,rent</p>
								</div>
							</a>
						</li>
					</ul>
				</div>
				<div class="advertise_column">
					<div class="advertise_column_item">
						<label for="">Advertise here...</label>
						<p class="text-color-blue">Contact: promote@adnlist.com</p>
					</div>
					<br>
					<div class="advertise_column_item">
						<label for="">Advertise here...</label>
						<p class="text-color-blue">Contact: promote@adnlist.com</p>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid m-t-5 fluid_padding">
		
	</div>
	
</section>


<script>
	var autocomplete;
	$(document).ready(function(){		
		$(".btn-home-search").click(function(){
			
			$(".homesearchTolist").submit();
		})
	});

	function fillInAddress()
	{ 		
		var place = autocomplete.getPlace();		
		var address_components = place.address_components;        
            
        $.each(address_components, function(index, component){
            var types = component.types;			 
            $.each(types, function(index, type){
                if(type == 'locality') {
                    city = component.long_name;                
                }
                if(type == 'administrative_area_level_1') {
                    state = component.short_name;
                }
                if(type == 'administrative_area_level_2') {
                    county = component.short_name;
                    county = county.replace(' County','');
                }
            });
        });
    
        $(".search_city").val(city);
        $(".search_state").val(state);        
        $(".search_county").val(county);
	
		if(county != "")
		{			
			$(".cs_home_show_county").html(county+' County, '+state);
		}
		else
		{
			$(".cs_home_show_county").html("");
		}

		$.ajax({
			url: "/register_position",
			data: {county: county,state: state,city: city},
			dataType: "json",
			type: "get",
			success: function(data)
			{
				location.reload();				
			}
		});
	}
	function initMap() 
	{ 		 
		autocomplete = new google.maps.places.Autocomplete(document.getElementById('welcomelocation'), {types: ['(cities)'],componentRestrictions: {country: "us"}}); 
		autocomplete.addListener('place_changed', fillInAddress);
	}
</script>
<?php $__env->stopSection(); ?>
	

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/welcome.blade.php ENDPATH**/ ?>