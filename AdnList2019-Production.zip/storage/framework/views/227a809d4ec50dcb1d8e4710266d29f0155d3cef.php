<?php $__env->startSection('content'); ?>

 
 <div class="content-wrapper">
     
      <section class="content-header">
        <h3>Manage price plan</h3>        
      </section>      
      <section class="content">        
        <div class="row">          
            <div class="col-xs-12">
                <div class="normal_border">
                    <form action="<?php echo e(route('admin_addtional')); ?>" class="plan_update_form" method="POST">
                    <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-xs-2">
                                <label for="">Category</label>
                            </div>
                            <div class="col-xs-10">
                                <select type="text" name="selected_category_slug" class="form-control selected_category" required>
                                    <option value=""></option>
                                    <?php $__currentLoopData = $all_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option <?php if(($cur_category !="") && ($item->slug == $cur_category->slug)): ?> selected <?php endif; ?> value="<?php echo e($item->slug); ?>"><?php echo e($item->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                    
                                </select>
                            </div>
                        </div>
                    <br>
                        <div class="row">
                            <div class="col-xs-2">
                                <label for="">Additional text</label>
                            </div>
                            <div class="col-xs-10">
                                <textarea name="additional_text" class="form-control additional_text"><?php if($cur_category != ""): ?><?php echo e($cur_category->additional_text); ?><?php endif; ?></textarea>
                            </div>
                            <div class="col-xs-12 text-center">
                                <button class="add_newaccount_btn btn_search m-t-10">Update</button>
                            </div>
                        </div>
                    </form>                        
                </div>
            </div> 
        </div>     

      </section>
    </div>    
    <script>
    
        $(document).ready(function(){
            $(".additional_text").summernote('code');
            $(".selected_category").change(function(){
                
                var selected_category_slug =  $(".selected_category").val();
                if(selected_category_slug == "")
                {
                    $(".additional_text").html(""); 
                    return false;
                }
                var formdata = new FormData;
                formdata.append('selected_category_slug',selected_category_slug);
                formdata.append('_token',$('input[name=_token]').val());    
                $.ajax({
                    url: "/getadditionaltext",
                    type: "post",
                    dataType: "json",
                    data: formdata,
                    processData: false,
                    contentType: false,
                    success: function(result){                         
                        $(".additional_text").summernote("code", result);                                             
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/admin/additional.blade.php ENDPATH**/ ?>