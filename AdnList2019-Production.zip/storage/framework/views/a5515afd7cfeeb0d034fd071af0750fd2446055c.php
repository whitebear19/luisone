

<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <title>Adnlist</title>
</head>

<body style="background:#f1f1f1;padding-top:20px;padding-bottom:20px;">
    <center>
        <table class="" border="0" cellspacing="0" cellpadding="0" width="600"
            style="width:6.25in;background:#ffffff; border-collapse:collapse">
            <tbody>
                <tr>
                    <td height="70">
                        <img src="https://mt.adnlist.com/assets/images/emailheader.png" width="100%;" alt="">
                    </td>
                </tr>
                
                <tr>
                    <td style="padding-left:20px;" align="center">
                        <p style="margin:5px 0px 5px 0px;font-weight:600;font-size:22px;">
                            <span style="color: #525f7f;font-family: arial;">Receipt from</span>
                            <span style="font-weight:600;color:#000000;">Adnlist</span>
                        </p>
                    </td>
                </tr>
                <tr>
                    <td style="padding-left:20px;" align="center">
                        <p style="margin: 10px 0px 10px 0px;
                            font-size: 16px;
                            color: #95b0c9;
                            font-family: Montserrat;">
                            Receipt: <?php echo e({{ $receipts['s_id']); ?> }}
                        </p>
                    </td>
                </tr>

                <tr>
                    <td height="40"></td>
                </tr>
                <tr>
                    <td>
                        <table class="" border="0" cellspacing="0" style="width: 100%;" cellpadding="0">
                            <tr>
                                <td style="width: 33%;" align="center">
                                    <span style="color: #8391a5;
                                    font-size: 14px;
                                    font-family: sans-serif;">AMOUNT PAID</span>
                                </td>
                                <td style="width: 33%;" align="center">
                                    <span style="color: #8391a5;
                                    font-size: 14px;
                                    font-family: sans-serif;">DATE PAID</span>
                                </td>
                                <td style="width: 33%;" align="center">
                                    <span style="color: #8391a5;
                                    font-size: 14px;
                                    font-family: sans-serif;">PAYMENT METHOD</span>
                                </td>
                            </tr>
                            <tr>
                                <td height="20" colspan="3"></td>
                            </tr>
                            <tr>
                                <td align="center">
                                    <span style="    color: #8391a5;
                                    font-size: 16px;
                                    font-family: sans-serif;
                                    font-weight: 600;">$<?php echo e($receipts['price']); ?></span>
                                </td>
                                <td align="center">
                                    <span style="    color: #8391a5;
                                    font-size: 16px;
                                    font-family: sans-serif;
                                    font-weight: 600;"><?php echo e($receipts['date']); ?></span>
                                </td>
                                <td align="center">
                                    <span style="    color: #8391a5;
                                    font-size: 16px;
                                    font-family: sans-serif;
                                    font-weight: 600;"><?php echo e($receipts['method']); ?></span>
                                </td>

                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td height="10"></td>
                </tr>
                <tr>
                    <td style="padding-left:20px;">
                        <p style="color: #8391a5;
                        font-size: 16px;
                        font-family: sans-serif;">Summary</p>
                    </td>
                </tr>
                <tr>
                    <td height="5"></td>
                </tr>
                
                <tr>
                    <td style="padding-left: 50px;">
                        <table>
                            <tr>
                                <td style="width: 430px;">
                                    <span style="color: #8391a5;
                                    font-size: 14px;
                                    font-family: sans-serif;">Classifieds-Activation fee - Please help us keep this website alive and contribute $2 for your Ad</span>
                                </td>
                                <td style="width: 100px;" align="center">
                                    <span style="color: #8391a5;
                                    font-size: 14px;
                                    font-family: sans-serif;">$<?php echo e($receipts['price']); ?></span>
                                </td>
                            </tr>
                            
                            <tr>
                                <td colspan="2" height="10">
                                    <hr>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" height="10">
                                    
                                </td>
                            </tr>
                            <tr>
                                <td style="width: 430px;">
                                    <span style="color: #8391a5;
                                    font-size: 14px;
                                    font-family: sans-serif;font-weight: 600;">Amount charged</span>
                                </td>
                                <td style="width: 100px;" align="center">
                                    <span style="color: #8391a5;
                                    font-size: 14px;
                                    font-family: sans-serif;font-weight: 600;">$<?php echo e($receipts['price']); ?></span>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" height="10">
                                    <hr>
                                </td>
                            </tr>
                            
                        </table>
                    </td>
                </tr>
                
                <tr>
                    <td height="10"></td>
                </tr>
                <tr>
                    <td style="padding-left: 50px;padding-right: 50px;">
                        <p>
                            <span style="color: #8391a5;
                            font-size: 16px;
                            font-family: sans-serif;">
                                If you have any questions, contact us at 
                                <span style="    color: #1741da;
                                font-weight: 600;
                                font-family: initial;">contact@adnlist.com</span> or call at 
                                <span style="color: #1741da;
                                    font-weight: 600;
                                    font-family: initial;">+1 858-405-0967</span>
                            </span>
                        </p>
                    </td>
                </tr>

                <tr>
                    <td height="10"></td>
                </tr>
                <tr>
                    <td style="padding: 0px 10px 0px 50px;" height="10">
                        <hr>
                    </td>
                </tr>
                <tr>
                    <td height="20">
                       
                    </td>
                </tr>
                <tr>
                    <td style="padding: 0px 10px 0px 50px;" height="10">
                        <span style="color: #8391a5;
                        font-size: 12px;
                        font-family: sans-serif;">
                            Something wrong with the email?
                        </span>
                        <span style="color: #1741da;
                        font-size: 12px;
                        font-family: sans-serif;">
                            View in your browser.
                        </span>
                    </td>
                </tr>
                <tr>
                    <td height="20">
                       
                    </td>
                </tr>
                <tr>
                    <td style="padding: 0px 10px 0px 50px;" height="10">
                        <span style="color: #8391a5;
                        font-size: 12px;
                        font-family: sans-serif;">
                            You're receiving this email because you made made a purchase at Adnlist which partners with <span style="color: blue;">Stripe</span> to provide invoicing and payment processing.
                        </span>                        
                    </td>
                </tr>
                <tr>
                    <td height="50">
                       
                    </td>
                </tr>
            </tbody>
        </table>


    </center>
</body>

</html>
<?php /**PATH D:\Daily-Work\Ramana\Adnlist\AdnList2019-Production\resources\views/email/receipts.blade.php ENDPATH**/ ?>