<?php $__env->startSection('style'); ?>    
    <link href="<?php echo e(asset('assets/css/font-awesome.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('assets/css/jquery-confirm.min.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>   
    <script src="<?php echo e(asset('assets/js/jquery-confirm.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<section class="auto_min_height clearfix user-page">
    <div class="container">
        <div class="row text-center">            
            <div class="col-sm-10 col-sm-offset-1 col-md-10 col-md-offset-1">           
                <div class="user-account">
                    <h4 class="modal-title text-center fs-16 text-color-green">You have already submitted this post.Please post new item.</h4>
                </div>                
            </div>		
        </div>
    </div>
</section>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\work\Ramana\www\AdnList2019\resources\views/user/stored.blade.php ENDPATH**/ ?>