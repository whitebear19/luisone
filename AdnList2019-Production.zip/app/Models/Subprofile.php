<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Subprofile extends Model
{
    protected $guarded = [];
}
