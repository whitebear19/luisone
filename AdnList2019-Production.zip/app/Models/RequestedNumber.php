<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class RequestedNumber extends Model
{
    protected $guarded = [];
}
