<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class SiteStatus extends Model
{
    protected $fillable =[
        'visitor',
        'Jan',
        'Feb',
        'Mar',
        'Apr',
        'May',
        'Jun',
        'Jul',
        'Aug',
        'Sep',
        'Oct',
        'Nov',
        'Dec',
    ];
}
