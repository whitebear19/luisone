
@extends('layouts.main')
@section('script')
    <script src="{{ asset('assets/js/address_autofill.js') }}"></script>
    <script src="{{ asset('assets/js/custom.js') }}"></script>        
@endsection
@section('style')   
    <link href="{{ asset('assets/css/font-awesome.min.css') }}" rel="stylesheet">    
    <link href="{{ asset('assets/css/slick.css') }}" rel="stylesheet">
@endsection
@section('content')
    <section id="listing_category" class="">
        <div class="container">
            <div class="row">
                <div class="col-md-3 text-left m-t-5 d-show">                    
                    <P class="category_detail"><a href="{{ url('/') }}" class="show_navigate_home"><span><i class="fa fa-home"></i></span></a><span class="show_navigate_status">@if(!empty($cur_category) && ($cur_category != "all")){{ $cur_category->name }}@else All Categories @endif</span></P>
                    <div class="accordion">                        
                        <div class="panel-group" id="accordion">
                            <div class="panel-default panel-faq">                                
                                <div class="panel-heading active-faq">
                                    <a data-toggle="collapse" data-parent="#accordion" href="#accordion-one"
                                        aria-expanded="true" class="">
                                        <h4 class="panel-title">What are you looking for?
                                            <span class="pull-right"><i class="fa fa-minus"></i></span>
                                        </h4>
                                    </a>
                                </div>

                                <div id="accordion-one" class="panel-collapse collapse in" tabindex="0"
                                    aria-expanded="true" style="">
                                    
                                    <div class="panel-body custom_scroll" id="cat-scroll">                                        
                                        @if(!empty($all_category))
                                            <ul role="tablist" class="cs_category_view_list">
                                                    <li>                                                        
                                                        <div class="all_category_view">
                                                            <span data-id="all" data-name="All Categories" class="category_list_item fs-16 p-l-30 
                                                            @if ($cur_category == "all")
                                                                selected
                                                            @endif
                                                            ">All Categories</span>                                    
                                                        </div>
                                                    </li>
                                                @foreach($all_category as $item)
                                                    <li>
                                                        <span class="select cat_icon_style">
                                                            <img class="category_view_image" src="{{ asset($item->image) }}" alt="Images">
                                                        </span>
                                                        @if($cur_category =="all")
                                                            <span class="category_list_item" data-name="{{ $item->name }}" data-id="{{ $item->id }}">{{ $item->name }}</span>
                                                        @else
                                                            @if($cur_category->slug == $item->slug) <span data-name="{{ $item->name }}" data-id="{{ $item->id }}" class="category_list_item selected checked" style="letter-spacing:-0.2px">{{ $item->name }}</span> @else <span data-id="{{ $item->id }}" data-name="{{ $item->name }}" class="category_list_item">{{ $item->name }}</span> @endif 
                                                        @endif
                                                        
                                                    </li>
                                                @endforeach
                                            </ul>
                                        @endif
                                    </div>
                                </div>                                
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-9 m-t-5">                    
                    <div class="search_form_listing intro_text_wrap d-show">                        
                        <form action="" class="search-form search-form-view" method='get'>                        
                            <div class="row">
                                <div class="col-sm-4 search_p_r_0">
                                    <div class="m-t-5 m-b-5">                                                
                                        <input type="text" id="welcomelocation" class="form-control text-color-blue" name="location" value="@if(!empty($city)){{ $city }}, {{ $state }},{{ "US" }} @endif">
                                        <input type="hidden" name="autofill_city" class="autofill_city" value="">
                                        <input type="hidden" name="search_city" class="search_city" value="{{ $city }}">
                                        <input type="hidden" name="search_county" class="search_county" value="{{ $county }}">
                                        <input type="hidden" name="search_state" class="search_state" value="{{ $state }}">   
                                        <input type="hidden" name="sub_category" class="sub_category" value="">   
                                        <input type="hidden" name="category_id" class="category_id" value="{{ $category_id }}">   
                                        <input type="hidden" name="sub_cat_id" class="sub_cat_id" value="{{ $sub_cat_id }}">   
                                        <input type="hidden" name="nationwide" value="{{ $nationwide }}">
                                        <p class="show_cur_location_in_view d-none"><span class="sel_address_with_count">{{ $county }}&nbsp;County,{{ $state }}</span> Classifieds</p>  
                                    </div>
                                </div>    
                                <div class="col-sm-4 search_p_r_0">                                            
                                    <div class="m-t-5 m-b-5">                                                
                                        <input type="text" class="form-control auto_submit" name="search" placeholder="Search word" value="@if (!empty($search)){{ $search }}@elseif(session('search')){{ session('search') }}@endif">
                                    </div>
                                </div>    
                                  
                                <div class="col-sm-4">
                                    <div class="m-t-5 m-b-5">                                               
                                        <div class="text-center">
                                            <div class="m-t-0 tablinks_wrap">
                                                <button type="button" class="btn_search_view">Search</button>
                                                <button class="tablinks view_list text-color-green" type="button" data-value="list"><i class="fa fa-th-list"></i> </button>
                                                <button class="tablinks view_grid" type="button" data-value="grid"><i class="fa fa-th-large"></i> </button>
                                                <button class="tablinks view_col" type="button" data-value="col"><i class="fa fa-align-justify"></i> </button>                                                
                                            </div>                                            
                                        </div>                                                
                                    </div>
                                </div>
                            </div>                                                           
                        </form>
                    </div>  
                    
                    <div class="m-show m-t-10">
                        <div class="d-flex just-content-btw">
                            <div class="category_detail">
                                <a href="{{ url('/') }}" class="show_navigate_home"><span><i class="fa fa-home"></i></span></a>
                                <span class="m_show_navigate_status">@if(!empty($cur_category) && ($cur_category != "all")){{ $cur_category->name }}@else All Categories @endif</span>
                            </div>
                            <div class="d-flex">
                                <label for="" class="fs-18" style="font-family: initial;line-height:34px;">Categories</label>
                               
                                <div class="dropdown">
                                    <button class="btn_transparent btn_m_show_category fs-22" type="button" data-toggle="dropdown">
                                        <img src="{{ asset('assets/images/thumb_icon.png') }}" alt="">
                                    </button>
                                    <div class="dropdown-menu m_category_dropdown_wrap">
                                        <div class="content">
                                            

                                            
                                            @if(empty(!$all_category))
                                                <ul class="">                          
                                                    @foreach($all_category as $item)                                                                                            
                                                        <li class="text-center category_list_item" data-name="{{ $item->name }}" data-id="{{ $item->id }}">
                                                            <a href="javascript:;" data-value="{{$item->id}}" data-price="{{ $item->price }}" data-slug="{{ $item->slug }}">
                                                                <div class="m-category-item">
                                                                    <div>
                                                                        <img class="img-" src="{{ asset($item->image) }}" alt="Images">
                                                                    </div>
                                                                    <div>
                                                                        @if($cur_category =="all")
                                                                            <span class="" data-id="{{ $item->id }}">{{ $item->name }}</span>
                                                                        @else
                                                                            @if($cur_category->slug == $item->slug) <span data-id="{{ $item->id }}" class="selected checked" style="letter-spacing:-0.2px">{{ $item->name }}</span> @else <span data-id="{{ $item->id }}" class="">{{ $item->name }}</span> @endif 
                                                                        @endif
                                                                    </div>
                                                                </div>
                                                            </a>
                                                        </li>
                                                    @endforeach
                                                    <li class="text-center category_list_item category_list_item_all" data-name="All Categories" data-id="all">
                                                        <a href="javascript:;" data-value="all" data-price="all" data-slug="all">
                                                            <div class="m-category-item">
                                                                <div class="text-center">
                                                                    <span class="all_cat_icon">
                                                                        All
                                                                    </span>                                                                    
                                                                </div>
                                                                <div>
                                                                    <span class="" data-id="all">Categories</span>
                                                                </div>
                                                            </div>
                                                        </a>
                                                    </li>        
                                                </ul>
                                            @endif	
                                        </div>
                                        
                                    </div>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>

                    
                    <div class="m-t-10 area_subcategory">
                        <div class="area_subcategory_ul d-show">
                                                         
                        </div>
                        <div class="area_subcategory_ul m_area_subcategory_ul m-show">
                                                         
                        </div>
                    </div>
                    <div class="m-t-5 d-flex just-content-btw">
                        <div class="d-show">
                            <p class="show_cur_location_in_view"><span class="sel_address_with_count  cur_pointer">{{ $city }}</span> and near by</p>   
                        </div>
                        <div class="m-show">
                            <p class="show_cur_location_in_view show_cur_location_in_view_for_mo"><span class="sel_address_with_count btn_set_locatoin btn_set_locatoin_caption cur_pointer selected">{{ $city }}</span> and near by</p>   
                            <p class="show_nationview_in_view">
                                <span class="sel_address_with_count btn_set_locatoin cur_pointer selected" style="line-height: 24px;">Nationwide</span>
                                <button class="btn_get_cur_location btn_transparent">
                                    <svg aria-hidden="true" class="size-20" focusable="false" data-prefix="fas" data-icon="crosshairs" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512"><path fill="currentColor" d="M500 224h-30.364C455.724 130.325 381.675 56.276 288 42.364V12c0-6.627-5.373-12-12-12h-40c-6.627 0-12 5.373-12 12v30.364C130.325 56.276 56.276 130.325 42.364 224H12c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h30.364C56.276 381.675 130.325 455.724 224 469.636V500c0 6.627 5.373 12 12 12h40c6.627 0 12-5.373 12-12v-30.364C381.675 455.724 455.724 381.675 469.636 288H500c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12zM288 404.634V364c0-6.627-5.373-12-12-12h-40c-6.627 0-12 5.373-12 12v40.634C165.826 392.232 119.783 346.243 107.366 288H148c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-40.634C119.768 165.826 165.757 119.783 224 107.366V148c0 6.627 5.373 12 12 12h40c6.627 0 12-5.373 12-12v-40.634C346.174 119.768 392.217 165.757 404.634 224H364c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h40.634C392.232 346.174 346.243 392.217 288 404.634zM288 256c0 17.673-14.327 32-32 32s-32-14.327-32-32c0-17.673 14.327-32 32-32s32 14.327 32 32z" class=""></path></svg>
                                </button>
                            </p>   
                        </div>
                        
                        <div class="m-t-0 tablinks_wrap m-show">                            
                            <button class="tablinks view_list text-color-green" type="button" data-value="list"><i class="fa fa-th-list"></i> </button>
                            <button class="tablinks view_grid" type="button" data-value="grid"><i class="fa fa-th-large"></i> </button>
                            <button class="tablinks view_col" type="button" data-value="col"><i class="fa fa-align-justify"></i> </button>                                                
                        </div>         
                    </div>
                    <div class="m-t-7">                               
                        <div id="Grid" class="tabcontent grid" style="display:none;">
                            <div class="row post_grid">
                                
                            </div>
                        </div>

                        <div id="List" class="tabcontent" style="">
                            <div class="">
                                <ul class="p-l-0 post_list">
                                
                                </ul>                            
                            </div>
                            
                        </div>
                        <div id="Col" class="tabcontent" style="display:none;">
                            <!-- ad-item -->
                            <div class="row table-responsive resp_margin_auto" style="min-height: 100px">
                                <div class="col-md-12">                                                           
                                    <ul class="normal_ul post_col">
                                                                        
                                    </ul>  
                                </div>
                            </div>
                        </div>
                       

                        <div class="row">
                            <div class="col-md-12 m-t-20">
                                <div class="logo_loading">
                                    <img class="" src="{{ asset('assets/images/logo_loading.png') }}" alt="">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <section id="listing_banner" class="section_padding m-t-30">
        <div class="container-fluid fluid-padding">
            <div class="row">
                <div class="col-md-12 text-center">
                    <h2 class="m-b-20">Do you have something to post?</h2>
                    <h5 class="m-b-20">Post your ad for free on adnlist.com</h5>
                    @if(Auth::check())
                        <a href="{{ route('create_post') }}" class="btn">Post Your Ad</a>
                    @else
                        <a href="javascript:;" data-toggle="modal" data-value="login" data-target="#signModal" class="btn">Post Your Ad</a>
                    @endif
                </div>
            </div>
        </div>
    </section>

    <div class="m_category_list_wrap">
        <div style="padding-top: 60px;background:transparent;">        
            @if(!empty($all_category))
                <ul role="tablist" class="cs_category_view_list m_category_list_box">
                        <li>                                                        
                            <div class="all_category_view">
                                <span data-id="all" class="category_list_item fs-16 p-l-30 
                                @if ($cur_category == "all")
                                    selected
                                @endif
                                "><b>All Categories</b></span>                                    
                            </div>
                        </li>
                    @foreach($all_category as $item)
                        <li>
                            <span class="select cat_icon_style">
                                <img class="category_view_image" src="{{ asset($item->image) }}" alt="Images">
                            </span>
                            @if($cur_category =="all")
                                <span class="category_list_item" data-id="{{ $item->id }}">{{ $item->name }}</span>
                            @else
                                @if($cur_category->slug == $item->slug) <span data-id="{{ $item->id }}" class="category_list_item selected checked" style="letter-spacing:-0.2px">{{ $item->name }}</span> @else <span data-id="{{ $item->id }}" class="category_list_item">{{ $item->name }}</span> @endif 
                            @endif
                        </li>
                    @endforeach
                </ul>
            @endif
		</div>
    </div>
    <input type="hidden" class="which_page" value="view">
    
    <script>
        var pagenum_cur = 1;
        var pagenum_max = 1;
        var autocomplete;        
        var m_autocomplete;        
        var needSetSlick = true;

        function isNeedSlick()
        {
            var total_width = $(".area_subcategory_ul").width();
            var compare_width = 0;
            $(".area_subcategory_ul .item-subcat").each(function() {
                compare_width += $(this).width();
            });
            // if(total_width > compare_width)
            // {
            //     return false;
            // }
            // else
            // {
            //     return true;
            // }
            if (window.matchMedia("(max-width: 767px)").matches) 
            { 
                
               return true;
            } else { 
                
                return false;
            } 
        }
       
        function setSlick()
        {            
            $(".m_area_subcategory_ul").slick({
                dots: false,
                infinite: true,
                speed: 90,
                slidesToShow: 1,
                slidesToScroll: 1,
                centerMode: false,
                swipeToSlide: true,
                variableWidth: true
            });
            var right_arrow = `
                <svg class="size-20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-circle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-chevron-circle-right fa-w-16 fa-3x"><path fill="currentColor" d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm113.9 231L234.4 103.5c-9.4-9.4-24.6-9.4-33.9 0l-17 17c-9.4 9.4-9.4 24.6 0 33.9L285.1 256 183.5 357.6c-9.4 9.4-9.4 24.6 0 33.9l17 17c9.4 9.4 24.6 9.4 33.9 0L369.9 273c9.4-9.4 9.4-24.6 0-34z" class=""></path></svg>
            `;
            $(".slick-next").html(right_arrow);
            var left_arrow = `
                <svg class="size-20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-circle-left" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-chevron-circle-left fa-w-16 fa-2x"><path fill="currentColor" d="M256 504C119 504 8 393 8 256S119 8 256 8s248 111 248 248-111 248-248 248zM142.1 273l135.5 135.5c9.4 9.4 24.6 9.4 33.9 0l17-17c9.4-9.4 9.4-24.6 0-33.9L226.9 256l101.6-101.6c9.4-9.4 9.4-24.6 0-33.9l-17-17c-9.4-9.4-24.6-9.4-33.9 0L142.1 239c-9.4 9.4-9.4 24.6 0 34z" class=""></path></svg>
            `;
            $(".slick-prev").html(left_arrow);
            needSetSlick = false;
        }
        function get_posts_view()
        {
            $(".logo_loading").css("display","block");
            var data = $(".search-form").serialize();
            $.ajax({
                url: '/api/get_posts_view?page='+pagenum_cur,
                type: 'get',
                dataType: 'json',
                data: data,
                success : function(data) {
                    $(".logo_loading").css("display","none");
                    var results = data.results;
                    pagenum_max = data.pagenum_max;
                    var sub_list = data.sub_list;
                    console.log(data);      
                    var sub_id = data.sub_id;              
                    if(results.length > 0)
                    {
                        
                        for (let index = 0; index < results.length; index++) {
                            var htmlgrid = `
                            <div class="post_item_width_view">
                                <div class="post_wrap">
                                    <div class="post_img">
                                        <span class="like_post">${results[index].cat_name}</span>
                                        <a class="get_pid" data_pid="${results[index].id}" href="/category_view/detail/${results[index].id}/${sub_id}"><img style="width:100%;" class="" src="${results[index].img}" alt="image"></a>
                                    </div>
                                    <div class="post_info">
                                        <div class="post_info_title">
                                            <h4><a class="get_pid" data_pid="${results[index].id}" href="/category_view/detail/${results[index].id}/${sub_id}"> <span class="common_post_title">${results[index].title}</span> </a></h4>
                                        </div>
                                        <div class="post_meta">                                                    
                                            <p class="left"><span><i class="fa fa-map-marker m-r-5"></i></span> <span class="location_time">${results[index].location}</span></p>
                                            <p class="right location_time"> <i class="fa fa-dot-circle-o m-r-5"></i>${results[index].created_at}</p>
                                        </div>	
                                    </div>
                                </div>
                            </div>
                            
                            `;
                            $(".post_grid").append(htmlgrid);

                            var htmllist = `
                                <li style="list-style-type:none;">
                                    <div class="" style="border: 1px solid #e3e3e3; ">
                                        <div class="item-image">
                                            <a href="/category_view/detail/${results[index].id}/${sub_id}" class="post_url get_pid" data_pid="${results[index].id}">
                                                <img src="${results[index].img}" alt="Image"
                                                    class="img-responsive">
                                            </a>                                                    
                                        </div> 
                                        <div class="ad-info"> 
                                            <h4 class="item-title"><a data_pid="${results[index].id}" class="post_url get_pid" href="/category_view/detail/${results[index].id}/${sub_id}"><span class="common_post_title">${results[index].title}</span></a></h4>
                                            <div class="item-cat">
                                                <span>${results[index].cat_name}</span>                                
                                            </div>
                                            <div class="item-cat location_time">
                                                <span class="m-r-20"><i class="fa fa-dot-circle-o m-r-5"></i>${results[index].created_at}</span> 
                                                <span><i class="fa fa-map-marker m-r-5"></i>${results[index].location}</span>                                   
                                            </div>
                                        </div>
                                    </div>
                                </li>
                            `;
                            $(".post_list").append(htmllist);

                            var htmlcol = `
                                <li>
                                    <a href="/category_view/detail/${results[index].id}/${sub_id}" data_pid="${results[index].id}" class="get_pid text-justify M_disp_flex normal-title">
                                        <div class="item-image d-show"><label class="col-black m-r-10 fs-14 m-t-5">${results[index].created_at}</label></div>
                                        <div class="ad-info">
                                            <div class="list_view_title">
                                                <p class="list-title common_post_title">${results[index].title}</p>
                                            </div>
                                            
                                            <p class="left fs-14 text-color-grey location_time" style="line-height:12px;font-weight:400;">
                                                <span><i class="fa fa-map-marker price"></i></span> <span>${results[index].location}</span>
                                                <span class="col-black m-l-10 fs-14"><i class="fa fa-dot-circle-o m-r-5"></i> ${results[index].created_at}</span>    
                                            </p>
                                        </div>                                                    
                                    </a>
                                </li>
                            `;
                            $(".post_col").append(htmlcol);
                        }
                    }
                    else
                    {
                        var html = `
                            <div class="row">                                    
                                <div class="col-sm-12">
                                    <p class="" style="text-align:center;font-family:initial;"><b>Nothing found!</b></p>
                                </div>
                            </div>
                        `;
                        $(".post_grid").append(html);
                        $(".post_list").append(html);
                        $(".post_col").append(html);
                    }
                    if(needSetSlick)
                    {
                        if(sub_list.length>0)
                        {                            
                            var html = `
                                <div class="item-subcat">
                                    <button data-value="all" class="btn_subcat_item btn_subcat_item_all">
                                        All
                                    </button>
                                </div>      
                            `;
                            $(".area_subcategory_ul").append(html);

                            for (let index = 0; index < sub_list.length; index++) {
                                var name = '';
                                if(sub_list[index].is_main == "1")
                                {
                                    name = "All " + sub_list[index].name;
                                }
                                else
                                {
                                    name = sub_list[index].name;
                                }
                                var html = `
                                    <div class="item-subcat">
                                        <button data-value="${sub_list[index].id}" class="btn_subcat_item">
                                            ${name}
                                        </button>
                                    </div>      
                                `;
                                $(".area_subcategory_ul").append(html);
                            }   
                           
                            // if(isNeedSlick())
                            // {
                                setSlick();
                            // }                            
                            $(".btn_subcat_item[data-value='"+sub_id+"']").addClass("selected_underline");
                        }
                        var sub_cat_id = $(".sub_cat_id").val();
                        sub_cat_id = sub_cat_id.split(" ");
                        for (let index = 0; index < sub_cat_id.length; index++) {
                            console.log(sub_cat_id[index]);          
                            $(".btn_subcat_item[data-value='"+sub_cat_id[index]+"']").addClass("selected_underline"); 
                        }
                        needSetSlick = false;
                    }                    

                },
                error: function(data) {
                    $(".logo_loading").css("display","none");
                }
            });
        }
        function init_post_area()
        {
            $(".post_grid").html("");
            $(".post_list").html("");
            $(".post_col").html("");        
            pagenum_cur = 1;   
        }
        function init_sub_area()
        {            
            $(".area_subcategory_ul").html("");                         
            $(".area_subcategory_ul").removeClass("slick-initialized slick-slider");   
            needSetSlick = true;   
            $(".sub_cat_id").val("");
        }        
        $(document).ready(function()
        {
            
            get_posts_view();
            $(window).scroll(function() {
                if($(window).scrollTop() + $(window).height() == $(document).height()) {
                    if(pagenum_cur >= pagenum_max)
                    {
                        return false;
                    }
                    else
                    {
                        pagenum_cur +=1;
                        get_posts_view();
                    }
                }
            });
            if($('input[name="nationwide"]').val() == "1")
            {
                $(".show_nationview_in_view").css("display",'flex');
               
                $(".show_cur_location_in_view").css("display",'none');
            }
            $(document).on('click','.btn_subcat_item',function(){            
                
                if($(this).data('value') == "all")
                {
                    $(".btn_subcat_item").removeClass("selected_underline");
                    $(this).addClass("selected_underline");
                }
                else
                {
                    $(".btn_subcat_item[data-value='all']").removeClass("selected_underline");
                    if($(this).hasClass("selected_underline"))
                    {
                        $(this).removeClass("selected_underline");
                    }
                    else
                    {
                        $(this).addClass("selected_underline");
                    }
                }
                
                
                var value = "";

                $(".btn_subcat_item.selected_underline").each(function() {
                    value = value + " " + $(this).data('value');
                });

                $(".sub_cat_id").val(value);
                needSetSlick = false;   
                init_post_area();
                get_posts_view();
            });

            $(document).on('click','.btn_m_search_nationawide',function(){            
                $(".btn_subcat_item").removeClass("selected");
                $(".btn_subcat_item_all").addClass("selected");
               
                $(".sub_cat_id").val('all');
                init_post_area();
                get_posts_view();
            });
            

            $(document).on('click','.category_list_item',function(){  
                $(".category_list_item").removeClass("selected");
                $(".category_list_item span").removeClass("selected");
                $(this).addClass("selected");
                var id = $(this).data("id");
                $(".category_id").val(id);
                var content = $(this).data('name');
                $(".show_navigate_status").html(content);
                console.log(content);
                $(".m_show_navigate_status").html(content);
                needSetSlick = true;
                init_post_area();
                init_sub_area();
                get_posts_view();
            });                      
           
            $(document).on("click",".btn_search_view",function(){
                init_post_area();
                get_posts_view();
            });
            $(document).on("click",".btn_m_search_view",function(){
                var search_word = $(".m_search_input").val();
                $(".search-form-view input[name='search']").val(search_word);
                init_post_area();
                get_posts_view();
            });
            $(document).on('click','.btn_search_nationawide_view',function(){
                $("input[name='nationwide']").val("1");
                $(".show_nationview_in_view").css("display",'flex');
                $(".show_cur_location_in_view .sel_address_with_count").html("");
                $(".show_cur_location_in_view_for_mo").css("display",'none');
                $("#welcomelocation").val("");
                $(".search_city").val("");
                $(".search_county").val("");
                $(".search_state").val("");
                $(".m_welcomelocation").val("");
            });    
            
            $(document).on("click",".m_category_list_wrap",function(){
                $(".m_category_list_wrap").toggle("slow");                
            });
            $(document).on("click",".btn_m_show_category",function(){
                // $(".m_category_list_wrap").toggle("slow");                
            });
            $(document).on('click','.btn_close_set_location_view',function(){
                $(".m_set_location_modal_wrap").toggle('slow');
                init_post_area();
                get_posts_view();
            });  
             
        });

        function m_setAddress()
        { 		
            var place = m_autocomplete.getPlace();		
            var address_components = place.address_components;        
                
            $.each(address_components, function(index, component){
                var types = component.types;			 
                $.each(types, function(index, type){
                    if(type == 'locality') {
                        city = component.long_name;                
                    }
                    if(type == 'administrative_area_level_1') {
                        state = component.short_name;
                    }
                    if(type == 'administrative_area_level_2') {
                        county = component.short_name;
                        county = county.replace(' County','');
                    }
                });
            });
        
            $(".search_city").val(city);
            $(".search_state").val(state);        
            $(".search_county").val(county);
            $(".btn_set_locatoin_caption").html(city+","+state);
            var location_with_county = county+" County,"+state;
            $(".show_cur_location_in_view .sel_address_with_count").html(city);
            $(".show_cur_location_in_view_for_mo").css("display","block");
            $(".show_nationview_in_view").css("display","none");
            $("#welcomelocation").val(city+","+state+",USA");
            $("input[name='nationwide']").val("0");
            init_post_area();
		    get_posts_view();
        }
        
        function setAddress() {       
            var place = autocomplete.getPlace();  
            var address_components = place.address_components;        
                
            $.each(address_components, function(index, component){
                var types = component.types;			 
                $.each(types, function(index, type){
                    if(type == 'locality') {
                        city = component.long_name;                
                    }
                    if(type == 'administrative_area_level_1') {
                        state = component.short_name;
                    }
                    if(type == 'administrative_area_level_2') {
                        county = component.short_name;
                        county = county.replace(' County','');
                    }
                });
            });
        
            $(".search_city").val(city);
            $(".search_state").val(state);        
            $(".search_county").val(county);
            var location_with_county = county+" County,"+state;
            
            $(".show_cur_location_in_view .sel_address_with_count").html(city);
            // $(".show_cur_location_in_view").css("display","block");
            // $(".show_nationview_in_view").css("display","none");
            $(".btn_set_locatoin_caption").html(city+","+state);
            $("input[name='nationwide']").val("0");
            init_post_area();
		    get_posts_view();
            
        }
        function initMap() 
        { 		 
            m_autocomplete = new google.maps.places.Autocomplete(document.getElementById('m_welcomelocation'), {types: ['(cities)'],componentRestrictions: {country: "us"}}); 
            m_autocomplete.addListener('place_changed', m_setAddress);
            autocomplete = new google.maps.places.Autocomplete(document.getElementById('welcomelocation'), {types: ['(cities)'],componentRestrictions: {country: "us"}}); 
            autocomplete.addListener('place_changed', setAddress);
        }

    </script>
@endsection
    
	