@extends('layouts.main')

@section('content')
<section class="bg-primary-darker">
    <div class="row">
        <div class="col-md-12 text-center">
            <h2 class="home_title">Guidelines</h2>
        </div>
    </div>
</section>
<section id="main" class="clearfix contact-us">
    <div class="container">
        <div class="contactus m-t-50">
            <h4 class="title text-center">guidelines</h4>
            
            <div class="corporate-info">
                <div class="row">
                    
                    <div class="col-sm-12">
                        
                    </div>
                    
                   	
                </div>
            </div>
        </div>
    </div>
</section>
@endsection