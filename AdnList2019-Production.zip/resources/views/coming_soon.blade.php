<!DOCTYPE HTML>
<html lang="en">
<head>
    <title>AdnList</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="UTF-8">
    <link href="{{ asset('assets/css/comingsoon.css') }}" rel="stylesheet">
</head>
<body>
<div class="main-area center-text">
    <div class="display-table">
        <div class="display-table-cell">
            <h1 class="title font-white"><b>Comming Soon</b></h1>
            <p class="desc font-white">Sorry we are not yet in your area !</p>
            <p class="desc font-white"> We are coming soon !</p>                  
        </div>
    </div>
</div>
<section>
    
</section>
</html>
