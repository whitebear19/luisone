@extends('layouts.main')
@section('script')   
    
@endsection
@section('content')

<section id="banner" class="parallex-bg">
	<div class="container cs_home_border">		
		<div class="row">
			<div class="col-md-12 d-show">
				<div class="intro_text intro_text_wrap div_zindex">	
					<h1 class="cs_home_main_title">{{ trans('message.home_title') }}</h1>
					<div class="search_form_warp">
						<form action="/category_views" class="homesearchTolist" method="post">
							@csrf
							<ul>
								<li class="cs_home_search_location_fixed_width">
									<div class="form-group m_resp_mb_25">						
									<input type="text" class="form-control" id="welcomelocation" name="location" placeholder="{{ trans('message.home_placeholder_entercity') }}" value="@if(session('city') == "all" || session('city') == "") {{ "All cities" }} @else {{ session('city') }}, {{ session('state_a') }} , {{ session('country') }} @endif">										
									<p class="cs_home_added_county d-none"><span class="cs_home_show_county">@if(!empty(session('county'))) {{ session('county') }} {{ trans('message.county') }} , {{ session('state_a') }} @endif</span><span>&nbsp;{{ trans('message.classifieds') }}</span></p>

										<input type="hidden" name="homepage" value="home">
										<input type="hidden" name="search_city" class="search_city" value="@if(!empty(session('city'))) {{ session('city') }}@endif">
                                        <input type="hidden" name="search_county" class="search_county" value="@if(!empty(session('county'))) {{ session('county') }} @else {{ $county }}@endif">
										<input type="hidden" name="search_state" class="search_state" value="@if(!empty(session('state_a'))) {{ session('state_a') }} @else {{ $state }}@endif">   
										<input type="hidden" name="category_id" class="category_id" value="all">    
										<input type="hidden" name="nationwide" value="0">      
									</div>		
								</li>
								<li class="cs_home_search_width">
									<div class="form-group">
									<input type="text" class="form-control search_word" name="search" placeholder="{{ trans('message.home_enter_searchword') }}">
									</div>
								</li>
								<li>
									<div class="form-group search_btn">
										<input type="button" value="Search" style="height:38px;" class="btn btn-block btn-green btn-home-search">
									</div>
								</li>
							</ul>							
						</form>
					</div>
				</div>
			</div>
			<div class="col-md-8 d-show m-t-20">				
				<div class="cs_home_category_warp">	
					<ul>
						@if(empty(!$all_category))
							@foreach($all_category as $item)
								<li>									
									<a href="#" class="category_item_home" data-id="{{ $item->id }}">
										<div class="category_icon">
											<div class="category_icon_area category_icon_position{{ $item->id }}">
												<div class="category_icon_background">
												</div>												
											</div>											
											<div class="category_name_area">
												<p class="" title="{{ $item->name }}"><b>{{ $item->name }}</b></p>
											</div>																			
										</div>											
									</a>									
								</li>
							@endforeach
						@endif				
					</ul>	
				</div>
			</div>
			<div class="col-md-4 d-show m-t-20">
				
				@if (session('sentlink'))
					<div class="alert alert-success alert-dismissible" role="alert">
						<button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<strong>{{ trans('message.alert_warning') }}!</strong> <span>{{ session('sentlink') }}</span>
					</div>
				@endif
				<div class="cs_home_download_warp text-left">	
					<h3 class="fs-16">Download on</h3>
					<ul>
						<li>
							<a href="" class="download_icon">
								<img src="{{ asset('assets/images/app-store.svg') }}" alt="">
							</a>
						</li>
						<li>
							<a href="" class="download_icon">
								<img src="{{ asset('assets/images/google-play.svg') }}" alt="">
							</a>
						</li>
					</ul>
					<div class="cs_home_download_warp_sel">
						<ul>
							<li>
								<label class="radio_container">Phone number
									<input type="radio" checked="checked" name="radio" placeholder="Coming soon...">
									<span class="checkmark"></span>
								</label>
							</li>							
						</ul>
						<div>
							<div class="input_group">
								<span class="form_prepend">
									<svg style="width: 20px;height:20px;color:#707070;" aria-hidden="true" focusable="false" data-prefix="fal" data-icon="mobile-android-alt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" class="svg-inline--fa fa-mobile-android-alt fa-w-10 fa-3x"><path fill="currentColor" d="M224 96v240H96V96h128m48-96H48C21.5 0 0 21.5 0 48v416c0 26.5 21.5 48 48 48h224c26.5 0 48-21.5 48-48V48c0-26.5-21.5-48-48-48zM48 480c-8.8 0-16-7.2-16-16V48c0-8.8 7.2-16 16-16h224c8.8 0 16 7.2 16 16v416c0 8.8-7.2 16-16 16H48zM244 64H76c-6.6 0-12 5.4-12 12v280c0 6.6 5.4 12 12 12h168c6.6 0 12-5.4 12-12V76c0-6.6-5.4-12-12-12zm-48 352h-72c-6.6 0-12 5.4-12 12v8c0 6.6 5.4 12 12 12h72c6.6 0 12-5.4 12-12v-8c0-6.6-5.4-12-12-12z" class=""></path></svg>
								</span>
								<input class="form-control phone_number" type="text" maxlength="15" name="" placeholder="Coming soon...">
								<button class="btn_send btn_form_afterpend">
									send
								</button>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-12 m-show text-left">
				<div class="m_wrap_location">
					<label for="" class="m-b-0 m-r-10">Location:</label>
					<button class="btn_transparent btn_set_locatoin m-r-10 selected">@if(!empty(session('city'))) {{ session('city') }}@endif,@if(!empty(session('state_a'))) {{ session('state_a') }}@endif</button>
					<button class="btn_get_cur_location btn_transparent m-r-10">
						<svg aria-hidden="true" class="size-20" focusable="false" data-prefix="fas" data-icon="crosshairs" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-crosshairs fa-w-16 fa-3x"><path fill="currentColor" d="M500 224h-30.364C455.724 130.325 381.675 56.276 288 42.364V12c0-6.627-5.373-12-12-12h-40c-6.627 0-12 5.373-12 12v30.364C130.325 56.276 56.276 130.325 42.364 224H12c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h30.364C56.276 381.675 130.325 455.724 224 469.636V500c0 6.627 5.373 12 12 12h40c6.627 0 12-5.373 12-12v-30.364C381.675 455.724 455.724 381.675 469.636 288H500c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12zM288 404.634V364c0-6.627-5.373-12-12-12h-40c-6.627 0-12 5.373-12 12v40.634C165.826 392.232 119.783 346.243 107.366 288H148c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-40.634C119.768 165.826 165.757 119.783 224 107.366V148c0 6.627 5.373 12 12 12h40c6.627 0 12-5.373 12-12v-40.634C346.174 119.768 392.217 165.757 404.634 224H364c-6.627 0-12 5.373-12 12v40c0 6.627 5.373 12 12 12h40.634C392.232 346.174 346.243 392.217 288 404.634zM288 256c0 17.673-14.327 32-32 32s-32-14.327-32-32c0-17.673 14.327-32 32-32s32 14.327 32 32z" class=""></path></svg>
					</button>
				</div>				
			</div>
			<div class="col-md-12 m-show over-hidden" style="padding: 5px;">
				<div class="cs_home_category_warp_mobile">	
					<div class="m_category_wrap">
						@if(empty(!$all_category))
							@foreach($all_category as $item)
								<div class="m_cat_item">									
									<a href="#" class="category_item_home" data-id="{{ $item->id }}">
										<div class="category_icon">
											<div class="category_icon_area category_icon_position{{ $item->id }}">
												<div class="category_icon_background">
												</div>												
											</div>											
											<div class="category_name_area">
												<p class="" title="{{ $item->name }}"><b>{{ $item->name }}</b></p>
											</div>																			
										</div>											
									</a>									
								</div>
							@endforeach
						@endif				
					</div>						
				</div>
			</div>
			
			<div class="m-show">
				@include('layouts.download')
			</div>
			
			
		</div>		
		<div class="row d-none">
			<div class="col-md-6">
				<p class="text-center fs-14"><b>
					<span>{{ trans('business.hometext1') }}</span>
					<a href="" class="text-color-blue">{{ trans('business.registernow') }}</a></b>
				</p>
				<a href="" class="text-color-blue fs-16"><b>{{ trans('business.findbusiness') }}</b></a>
			</div>
			<div class="col-md-6">

			</div>
		</div>		
		

		<div class="row">		
			<div class="col-md-12 text-center">
				<h4 class="fs-18 title m-t-20 m-b-20">Recent updates</h4>
			</div>						
		</div>
		<div class="row post_area">

		</div>
		<div class="row">
			<div class="col-md-12 m-t-20">
				<div class="logo_loading">
					<img class="" src="{{ asset('assets/images/logo_loading.png') }}" alt="">
				</div>
			</div>
		</div>
	</div>
	<div class="container-fluid m-t-5 fluid_padding">
		
	</div>
	
	
	<div class="m_set_contact_info_wrap">
		<div class="m_set_contact_info">
			<button class="btn_transparent btn_colse_set_contact">
				<svg class="size-20" aria-hidden="true" focusable="false" data-prefix="far" data-icon="times" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" class="svg-inline--fa fa-times fa-w-10 fa-3x"><path fill="currentColor" d="M207.6 256l107.72-107.72c6.23-6.23 6.23-16.34 0-22.58l-25.03-25.03c-6.23-6.23-16.34-6.23-22.58 0L160 208.4 52.28 100.68c-6.23-6.23-16.34-6.23-22.58 0L4.68 125.7c-6.23 6.23-6.23 16.34 0 22.58L112.4 256 4.68 363.72c-6.23 6.23-6.23 16.34 0 22.58l25.03 25.03c6.23 6.23 16.34 6.23 22.58 0L160 303.6l107.72 107.72c6.23 6.23 16.34 6.23 22.58 0l25.03-25.03c6.23-6.23 6.23-16.34 0-22.58L207.6 256z" class=""></path></svg>
			</button>
			<div class="form-group m-b-0">
				<label for="" class="text-white">Enter phone number</label>
			</div>
			<div class="input_group">
				<span class="form_prepend">
					<svg style="width: 20px;height:20px;color:#707070;" aria-hidden="true" focusable="false" data-prefix="fal" data-icon="mobile-android-alt" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 320 512" class="svg-inline--fa fa-mobile-android-alt fa-w-10 fa-3x"><path fill="currentColor" d="M224 96v240H96V96h128m48-96H48C21.5 0 0 21.5 0 48v416c0 26.5 21.5 48 48 48h224c26.5 0 48-21.5 48-48V48c0-26.5-21.5-48-48-48zM48 480c-8.8 0-16-7.2-16-16V48c0-8.8 7.2-16 16-16h224c8.8 0 16 7.2 16 16v416c0 8.8-7.2 16-16 16H48zM244 64H76c-6.6 0-12 5.4-12 12v280c0 6.6 5.4 12 12 12h168c6.6 0 12-5.4 12-12V76c0-6.6-5.4-12-12-12zm-48 352h-72c-6.6 0-12 5.4-12 12v8c0 6.6 5.4 12 12 12h72c6.6 0 12-5.4 12-12v-8c0-6.6-5.4-12-12-12z" class=""></path></svg>
				</span>
				<input class="form-control m_phone_number" type="text" name="" maxlength="15" placeholder="Coming soon...">
				<button class="m_btn_send btn_form_afterpend">
					send
				</button>
			</div>
		</div>
	</div>
	

	<div class="modal fade" id="alertSend" role="dialog">                
        <div class="modal_signin_form">
            <div class="modal-dialog modal-dialog-for-download">
                <div class="modal-content modal-content-for-download">
                    <div class="modal_border_warp_for_download_alert">                       
                       <div class="row">
							<div class="col-md-12">
								<div class="text_for_download">
									<p>
										Thanks for your interest in downloading our app.
									</p>
									<p>
										Adnlist will notify you soon with app download link
									</p>
								</div>
								
								<button type="button" class="close btn_transparent fs-16" data-dismiss="modal">
									close
								</button>         
							</div>
					   </div>
                    </div>
                </div>
            </div>
        </div>            
    </div>

</section>
<input type="hidden" class="which_page" value="home">

<script>
	var pagenum_cur = 1;
	var pagenum_max = 1;
	var autocomplete;
	var m_autocomplete;
	function init_post_area()
	{
		$(".post_area").html("");		   
		pagenum_cur = 1;   
	}
	function get_posts_home()
	{
		var data = $(".homesearchTolist").serialize();
		
		$(".logo_loading").css("display","block");
		$.ajax({
			url: '/api/get_posts_home?page='+pagenum_cur,
			type: 'get',
			dataType: 'json',
			data: data,
			success : function(data) {
				$(".logo_loading").css("display","none");
				var results = data.results;
				pagenum_max = data.pagenum_max;
				console.log(results);
				console.log(pagenum_max);
				if(results.length>0)
				{
					for (let index = 0; index < results.length; index++) {
						var html = `
						<div class="post_item_width">
							<div class="post_wrap">
								<div class="post_img">
									<span class="like_post">${results[index].cat_name}</span>
									<a class="get_pid" data_pid="${results[index].id}" href="/category_view/detail/${results[index].id}/all"><img style="width:100%;" class="" src="${results[index].img}" alt="image"></a>
								</div>
								<div class="post_info">
									<div class="post_info_title">
										<h4><a class="get_pid" data_pid="${results[index].id}" href="/category_view/detail/${results[index].id}/all"> <span class="common_post_title">${results[index].title}</span> </a></h4>
									</div>
									<div class="post_meta">                                                    
										<p class="left"><span><i class="fa fa-map-marker m-r-5"></i></span> <span class="location_time">${results[index].location}</span></p>
										<p class="right location_time"> <i class="fa fa-dot-circle-o m-r-5"></i>${results[index].created_at}</p>
									</div>	
								</div>
							</div>
						</div>
						
						`;
						$(".post_area").append(html);
					}
				}
				else
				{
					var html = `
						<div class="col-md-12">
							<p class="text-center" style="font-family:initial;color:#727272;">No recent posts</p>
						</div>
					`;
					$(".post_area").append(html);
				}

			},
			error: function(data) {
				$(".logo_loading").css("display","none");
			}
		});
	}

	function setSlick()
	{
		$(".m_category_wrap").slick({
			dots: false,
			infinite: true,
			speed: 500,
			slidesToShow: 1,
			slidesToScroll: 1,
    		swipeToSlide: true,
			centerMode: false,
			variableWidth: true
		});
		var right_arrow = `
			<svg class="size-20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-circle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-chevron-circle-right fa-w-16 fa-3x"><path fill="currentColor" d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm113.9 231L234.4 103.5c-9.4-9.4-24.6-9.4-33.9 0l-17 17c-9.4 9.4-9.4 24.6 0 33.9L285.1 256 183.5 357.6c-9.4 9.4-9.4 24.6 0 33.9l17 17c9.4 9.4 24.6 9.4 33.9 0L369.9 273c9.4-9.4 9.4-24.6 0-34z" class=""></path></svg>
		`;
		$(".slick-next").html(right_arrow);
		var left_arrow = `
			<svg class="size-20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-circle-left" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-chevron-circle-left fa-w-16 fa-2x"><path fill="currentColor" d="M256 504C119 504 8 393 8 256S119 8 256 8s248 111 248 248-111 248-248 248zM142.1 273l135.5 135.5c9.4 9.4 24.6 9.4 33.9 0l17-17c9.4-9.4 9.4-24.6 0-33.9L226.9 256l101.6-101.6c9.4-9.4 9.4-24.6 0-33.9l-17-17c-9.4-9.4-24.6-9.4-33.9 0L142.1 239c-9.4 9.4-9.4 24.6 0 34z" class=""></path></svg>
		`;
		$(".slick-prev").html(left_arrow);
	}

	function isNumber(phone) {
		var regex = /^([0-9])/;
		return regex.test(phone);
	}

	$(document).ready(function(){		
		$(".btn-home-search").click(function(){			
			// $(".homesearchTolist").submit();
			init_post_area();
			get_posts_home();
		})
		$(".category_item_home").click(function(){
			var id = $(this).data("id");
			$(".category_id").val(id);
			$(".homesearchTolist").submit();
		});
		$(".slider").slick({            
            slidesToShow: 1,
            slidesToScroll: 1,
            swipeToSlide: false
        });
		
		$(document).on('click','.btn_colse_set_contact',function(){
			$(".m_set_contact_info_wrap").toggle('slow');
		});
		$(document).on('click','.btn_open_set_contact',function(){
			$(".m_set_contact_info_wrap").toggle('slow');
		});
		$(document).on('click','.btn_m_search_home',function(){
			var searchword = $(".m_search_input").val();
			$(".search_word").val(searchword);
			// $(".homesearchTolist").submit();
			init_post_area();
			get_posts_home();
		});

		$(document).on('click','.btn_search_nationawide',function(){
			
			$("input[name='nationwide']").val('1');
			$(".search_city").val("");
			$(".search_county").val("");
			$(".search_state").val("");
			$(".homesearchTolist").submit();
		});   

		$(".m_search_input").keyup(function(e){
            if(e.keyCode == 13)
            {
                var searchword = $(".m_search_input").val();
				$(".search_word").val(searchword);
				// $(".homesearchTolist").submit();
				init_post_area();
				get_posts_home();
            }
		});  
		
		$(".search_word").keyup(function(e){
            if(e.keyCode == 13)
            {
                init_post_area();
				get_posts_home();
            }
        });  
		
		$(document).on('click','.btn_close_set_location',function(){
			$(".m_set_location_modal_wrap").toggle('slow');
		});  
		$(document).on('click','.btn_send',function(){
			
			var phone_number = $(".phone_number").val();
			if(phone_number == "")
			{
				return false;
			}
			if(isNumber(phone_number))
			{
				$.ajax({
					url: '/api/store_phone_number',
					type: 'get',
					dataType: 'json',
					data: {phone_number:phone_number},
					success : function(data) {	
						if(data.result)			
						{
							$(".phone_number").val("");
							$("#alertSend").modal('show');		
							$(".m_set_contact_info_wrap").css('display','none');
						}	
						else
						{
							$(".text_for_download").html("");
							var html = `
								<p>
									This phone number already registered!	
								</p>
							`;
							$(".text_for_download").append(html);
							$("#alertSend").modal('show');	
						}	
										
					},
					error: function(data) {
						$(".text_for_download").html("");
						var html = `
							<p>
								Something wrong,please try again!	
							</p>
						`;
						$(".text_for_download").append(html);
						$("#alertSend").modal('show');	
						$(".m_set_contact_info_wrap").css('display','none');					
					}
				});
			}
			else
			{
				$(".text_for_download").html("");
				var html = `
					<p>
						This isn't phone number format.Please confirm.	
					</p>
				`;
				$(".text_for_download").append(html);
				$("#alertSend").modal('show');
			}
		});  

		$(document).on('click','.m_btn_send',function(){
			
			var phone_number = $(".m_phone_number").val();
			if(phone_number == "")
			{
				return false;
			}
			if(isNumber(phone_number))
			{
				$.ajax({
					url: '/api/store_phone_number',
					type: 'get',
					dataType: 'json',
					data: {phone_number:phone_number},
					success : function(data) {
						if(data.result)			
						{
							$(".m_phone_number").val("")
							$("#alertSend").modal('show');		
							$(".m_set_contact_info_wrap").css('display','none');
						}	
						else
						{
							$(".text_for_download").html("");
							var html = `
								<p>
									This phone number already registered!	
								</p>
							`;
							$(".text_for_download").append(html);
							$("#alertSend").modal('show');	
						}					
					},
					error: function(data) {
						$(".text_for_download").html("");
						var html = `
							<p>
								Something wrong,please try again!	
							</p>
						`;
						$(".text_for_download").append(html);
						$("#alertSend").modal('show');
						$(".m_set_contact_info_wrap").css('display','none');
					}
				});
			}
			else
			{
				$(".text_for_download").html("");
				var html = `
					<p>
						This isn't phone number format.Please confirm.	
					</p>
				`;
				$(".text_for_download").append(html);
				$("#alertSend").modal('show');
			}
		});  

		setSlick();
		get_posts_home();
		$(window).scroll(function() {
			if($(window).scrollTop() + $(window).height() == $(document).height()) {
				if(pagenum_cur >= pagenum_max)
				{
					return false;
				}
				else
				{
					pagenum_cur +=1;
					get_posts_home();
				}
			}
		});
	});

	
	function setAddress()
	{ 		
		var place = autocomplete.getPlace();		
		var address_components = place.address_components;        
            
        $.each(address_components, function(index, component){
            var types = component.types;			 
            $.each(types, function(index, type){
                if(type == 'locality') {
                    city = component.long_name;                
                }
                if(type == 'administrative_area_level_1') {
                    state = component.short_name;
                }
                if(type == 'administrative_area_level_2') {
                    county = component.short_name;
                    county = county.replace(' County','');
                }
            });
        });
    
        $(".search_city").val(city);
        $(".search_state").val(state);        
		$(".search_county").val(county);
		$(".btn_set_locatoin").html(city+","+state);
		var location_with_county = county+" County,"+state;
		$(".cs_home_show_county").html(location_with_county);

		init_post_area();
		get_posts_home();
	}

	function m_setAddress() {       
		var place = m_autocomplete.getPlace();  
		var address_components = place.address_components;        
			
		$.each(address_components, function(index, component){
			var types = component.types;			 
			$.each(types, function(index, type){
				if(type == 'locality') {
					city = component.long_name;                
				}
				if(type == 'administrative_area_level_1') {
					state = component.short_name;
				}
				if(type == 'administrative_area_level_2') {
					county = component.short_name;
					county = county.replace(' County','');
				}
			});
		});	
		$(".search_city").val(city);
        $(".search_state").val(state);        
		$(".search_county").val(county);
		$(".btn_set_locatoin").html(city+","+state);
		var location_with_county = county+" County,"+state;
		$(".cs_home_show_county").html(location_with_county);
		$("#welcomelocation").val(city+","+state+",USA");
		init_post_area();
		get_posts_home();
	}
	
	function initMap() 
	{ 
		autocomplete = new google.maps.places.Autocomplete(document.getElementById('welcomelocation'), {types: ['(cities)'],componentRestrictions: {country: "us"}}); 
		autocomplete.addListener('place_changed', setAddress);
		m_autocomplete = new google.maps.places.Autocomplete(document.getElementById('m_welcomelocation'), {types: ['(cities)'],componentRestrictions: {country: "us"}}); 
		m_autocomplete.addListener('place_changed', m_setAddress);
	}
	
	
	
</script>
@endsection
	
