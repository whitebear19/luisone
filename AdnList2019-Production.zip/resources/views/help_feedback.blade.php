@extends('layouts.main')

@section('content')

<section class="m-t-60">
    <div class="row">
        <div class="col-md-12 text-center">
            <h2 class="home_title">Help & Feedback</h2>
        </div>
    </div>
</section>
<section id="main" class="clearfix contact-us">
    <div class="container">
        <div class="contactus m-t-20">
            <h4 class="title text-center">Help Feedback</h4>

            

            <div class="corporate-info">
                <div class="row">
                    
                    <div class="col-sm-12">
                        
                    </div>
                    
                   	
                </div>
            </div>
        </div>
    </div>
</section>
@endsection