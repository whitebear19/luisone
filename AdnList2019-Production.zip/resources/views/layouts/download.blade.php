
    <div class="m-dropdown-app-wrap">
        <label for="" style="font-family: initial;font-weight:bold;">Download app</label>
        <div class="m-dropdown-app-icons">
            <button class="btn_transparent btn_open_set_contact ">
                <span class="download_icon" style="width: 135px;">
                    <img src="{{ asset('assets/images/app-store.svg') }}" alt="">
                </span>
                
            </button>
            <button class="btn_transparent btn_open_set_contact download_icon" style="padding: 0px;">
                <span class="download_icon" style="width: 135px;">
                    <img src="{{ asset('assets/images/google-play.svg') }}" alt="">
                </span>                
            </button>
        </div>
    </div>
