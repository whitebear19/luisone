

@section('style')
<link href="{{ asset('assets/css/font-awesome.min.css') }}" rel="stylesheet">
@endsection
@section('script')
    <script src="{{ asset('assets/js/custom.js') }}"></script>
    
@endsection
<div class="ad-profile section">	
    <div class="user-profile">
       
        <div class="user">
            <h2 class="m-t-10"><span class="fs-18">{{ trans('message.userprofile_welcome') }}</span> <span class="text-color-blue fs-20"> @if(!empty(Auth::user()->name)){{ Auth::user()->name }} @else @if(!empty(Auth::user()->fname)){{ Auth::user()->fname }} @endif @if(!empty(Auth::user()->lname)){{ Auth::user()->lname }} @endif  @endif</span></h2>            
        </div>
        <div style="float:right;" class="m-t-5">
            <form action="{{ route('update_user_status') }}" id="deactivate_form" class="update_user_status_form">
                <input type="hidden" name="user_id" value="{{ Auth::user()->id }}">
                <input type="hidden" name="user_status" value="2">
                <input type="hidden" name="user_side" value="true">
                <button type="button" class="btn btn-cancel delete_button_user">Deactivate account</button>                        
            </form>     
        </div>
    </div>
            
    <div class="user_account_nav_wrap">
        <ul class="user-menu">
            <li class="@if($page_name == 'profile') active @endif"><a href="{{ route('user_profile') }}">{{ trans('message.userprofile_profile') }}</a></li>
            <li class="@if($page_name == 'pwd') active @endif"><a href="{{ route('user_change_password') }}">{{ trans('message.userprofile_changepwd') }}</a></li>
            @if(Auth::user()->role == "0")
                <li class="@if($page_name == 'notification') active @endif"><a href="{{ route('user_messages','read') }}">Messages<span>(@if(!empty($userDetail['user_num_unread'])){{ $userDetail['user_num_unread'] }}@else 0 @endif)</span></a></li>
                <li class="@if($page_name == 'ads') active @endif"><a href="{{ route('user_advertisement') }}">{{ trans('message.userprofile_activeposts') }}<span>(@if(!empty($userDetail['user_ads_num'])){{ $userDetail['user_ads_num'] }} @else 0 @endif)</span></a></li>
                <li class="@if($page_name == 'pen') active @endif"><a href="{{ route('user_pending_approval_ads') }}">{{ trans('message.userprofile_pending') }}<span>(@if(!empty($userDetail['user_pending_num'])){{ $userDetail['user_pending_num'] }}@else 0 @endif)</span></a></li>
                <li class="@if($page_name == 'draft') active @endif"><a href="{{ route('user_draft_ads') }}">{{ trans('message.userprofile_draft') }}<span>(@if(!empty($userDetail['user_draft_num'])){{ $userDetail['user_draft_num'] }} @else 0 @endif)</span></a></li>
                <li class="@if($page_name == 'expired') active @endif"><a href="{{ route('user_expired_ads') }}">{{ trans('message.userprofile_expired') }}<span>(@if(!empty($userDetail['user_expired_num'])){{ $userDetail['user_expired_num'] }} @else 0 @endif)</span></a></li>
            @elseif(Auth::user()->role == "1")
                <li class="@if($page_name == '') active @endif"><a href="{{ route('user_messages','read') }}">{{ trans('message.userprofile_messages') }}</a></li>
                <li class="@if($page_name == '') active @endif"><a href="{{ route('user_advertisement') }}">{{ trans('message.userprofile_mylisting') }}<span>(@if(!empty($user_ads_num)){{ $user_ads_num }} @else 0 @endif)</span></a></li>
                <li class="@if($page_name == '') active @endif"><a href="{{ route('user_pending_approval_ads') }}">{{ trans('message.userprofile_sold') }}<span>(@if(!empty($user_pendding_num)){{ $user_pendding_num }} @else 0 @endif)</span></a></li>
                <li class="@if($page_name == '') active @endif"><a href="{{ route('user_draft_ads') }}">{{ trans('message.userprofile_selling') }}<span>(@if(!empty($user_draft_num)){{ $user_draft_num }} @else 0 @endif)</span></a></li>
                <li class="@if($page_name == '') active @endif"><a href="{{ route('user_draft_ads') }}">{{ trans('message.userprofile_waiting') }}<span>(@if(!empty($user_draft_num)){{ $user_draft_num }} @else 0 @endif)</span></a></li>
            @endif
        </ul>
    </div>
    
</div>
<script>
    $(function() {
        $(".delete_button_user").click(function(){
            if (confirm("Confirmation! Do you really want to deactivate this account?"))
            {
                $('form#deactivate_form').submit();
            }
        });        
    });
    function setSlick()
    {
        $(".user-menu").slick({
			dots: false,
			infinite: true,
			speed: 500,
			slidesToShow: 1,
			centerMode: false,
			variableWidth: true
		});
		var right_arrow = `
			<svg class="size-20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-circle-right" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-chevron-circle-right fa-w-16 fa-3x"><path fill="currentColor" d="M256 8c137 0 248 111 248 248S393 504 256 504 8 393 8 256 119 8 256 8zm113.9 231L234.4 103.5c-9.4-9.4-24.6-9.4-33.9 0l-17 17c-9.4 9.4-9.4 24.6 0 33.9L285.1 256 183.5 357.6c-9.4 9.4-9.4 24.6 0 33.9l17 17c9.4 9.4 24.6 9.4 33.9 0L369.9 273c9.4-9.4 9.4-24.6 0-34z" class=""></path></svg>
		`;
		$(".slick-next").html(right_arrow);
		var left_arrow = `
			<svg class="size-20" aria-hidden="true" focusable="false" data-prefix="fas" data-icon="chevron-circle-left" role="img" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 512 512" class="svg-inline--fa fa-chevron-circle-left fa-w-16 fa-2x"><path fill="currentColor" d="M256 504C119 504 8 393 8 256S119 8 256 8s248 111 248 248-111 248-248 248zM142.1 273l135.5 135.5c9.4 9.4 24.6 9.4 33.9 0l17-17c9.4-9.4 9.4-24.6 0-33.9L226.9 256l101.6-101.6c9.4-9.4 9.4-24.6 0-33.9l-17-17c-9.4-9.4-24.6-9.4-33.9 0L142.1 239c-9.4 9.4-9.4 24.6 0 34z" class=""></path></svg>
		`;
		$(".slick-prev").html(left_arrow);
    }
    $(document).ready(function(){
        if ($(window).width() < 960) {
            setSlick()
        }        
    });
</script>