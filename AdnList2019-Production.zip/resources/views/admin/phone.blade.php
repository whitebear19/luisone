@extends('layouts.admin')

@section('content')

 
 <div class="content-wrapper">
     
      <section class="content-header">
        <h3>Phone Numbers</h3>        
      </section>      
      <section class="content">        
        <div class="row">          
          <div class="col-xs-12">
            @if($phones)
                <div class="box-body table-responsive m-t-30">
                    <table id="example1" class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Phone Number</th>
                                <th>Date</th>                           
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($phones as $item)
                                <tr>
                                    <td><span>{{ $item->phone_number }}</span></td>
                                    <td><span>{{ $item->created_at }}</span></td>
                                    
                                </tr>
                            @endforeach  
                        </tbody>
                    </table>
                    <div style="text-align:center;">
                        {{ $phones->links() }}                
                    </div>
                </div>  
               
            @endif
                          
              
            </div>
          </div> 
        </div>     

      </section>
    </div>    

@endsection