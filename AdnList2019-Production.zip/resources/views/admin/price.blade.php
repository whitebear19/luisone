@extends('layouts.admin')

@section('content')

 
 <div class="content-wrapper">
     
      <section class="content-header">
        <h3>Manage price plan</h3>        
      </section>      
      <section class="content">      
        <div class="normal_border">  
            <div class="row">  
                <div class="col-md-6">
                    <label for="">Category</label>
                    <select name="" class="form-control category_list">
                        <option value="">-- Select --</option>
                        @foreach ($all_category as $item)
                            <option value="{{ $item->price }}" data-id="{{ $item->id }}">{{ $item->name }}</option>
                        @endforeach
                    </select>
                </div>
                <div class="col-md-6">
                    <label for="">Price($)</label>
                    <input type="number" class="form-control input_price" value="">
                </div>
                
                <div class="col-md-12 m-t-20 text-center">
                    <button class="btn_store_price btn_search text-center">Submit</button>
                </div>
                <div class="col-md-12 m-t-30">
                    <table class="table">
                        @foreach ($all_category as $item)                            
                            <tr>
                                <td style="width: 200px;">{{ $item->name }}</td>
                                <td style="width: 50px;">{{ $item->price }}$</td>
                            </tr>
                        @endforeach
                        
                    </table>
                </div>
            </div> 
        </div>
      </section>
    </div>    
    <script>            
        $(document).ready(function(){            
            $('.category_list').on('change', function() {
               
                var price = $(this).val();
                $(".input_price").val(price);
            });
            $(document).on('click','.btn_store_price',function(){
                var price = $(".input_price").val();
                var id = $(".category_list").find(':selected').data('id');
                if(price == "")
                {
                    return false;
                }
                else
                {                    
                    $.ajax({
                        url: '/api/admin/price',
                        type: 'get',
                        dataType: 'json',
                        data: {price:price,id:id},
                        success: function(data){
                            location.reload();
                        },
                        error: function(data){
                            location.reload();
                        }

                    });
                }
            });
        });
    </script>
@endsection
