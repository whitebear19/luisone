<?php

return [

    'hometext1' => 'Are you a business or individual service provider?',
    'registernow' => 'Register now',
    'findbusiness' => 'Find Local Business and Services',
    
];
